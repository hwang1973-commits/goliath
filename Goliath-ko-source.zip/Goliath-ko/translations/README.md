# Korean interface and game titles

`goliath_ko.ts` is the editable Qt Linguist catalog. `goliath_ko.qm` is its
compiled counterpart, embedded in the application through
`assets/translations.qrc`. Keep both files together in changes.

The Settings language selector saves `[UI] language=system`, `en`, or `ko` in
`goliath.ini`. The default follows the OS language; Korean is selected for a
Korean OS, with English as the fallback. Restart to apply a change.

Korean library titles use each ROM's nonblank `alt_title`; the original
English title appears in the alternate-title row. Missing alternate titles
retain their original names. This is a presentation copy only: the scanner's
catalog, media filenames, MAME IDs, verification hashes, Favorites, profiles,
and playtime keys remain unchanged. Rescans compare the original catalog.
Search includes both the original name and alternate titles in either language.
The alternate title is used as supplied by the catalog; it is not machine translated.

To add UI translations, call `goliath::uiText("English source")` at a QString
presentation boundary and add the same source in the `Goliath` context in the
TS file. For tables, keep identifiers stable and translate the displayed label
when constructing its widget. Preserve `%1`, `%2`, etc. placeholders.

Regenerate the catalog with a Qt Linguist Tools installation:

```sh
lrelease translations/goliath_ko.ts -qm translations/goliath_ko.qm
```

CMake exposes `goliath-update-translations` when it finds `lrelease` (or
`lrelease-qt6`/`lrelease-qt5`); specify `-DGOLIATH_LRELEASE=/path/to/lrelease`
if necessary. Normal builds use the bundled QM and need no extra Qt component.

This change localizes the main library, toolbar/filter labels, settings tabs,
common actions, and many video/audio/core controls. Some explanatory tooltips,
diagnostics, external emulator output, and supplied history text remain English.

Build and run regression tests using the project's usual Qt 6 / SDL3 toolchain:

```sh
cmake -S . -B build -G Ninja -DBUILD_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```
