<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="ko_KR" sourcelanguage="en_US">
  <context>
    <name>Goliath</name>
    <message>
      <source>  (showing %1 of %2)</source>
      <translation> (%2개 중 %1개 표시)</translation>
    </message>
    <message>
      <source> - Favorites: %1</source>
      <translation> - 즐겨찾기: %1</translation>
    </message>
    <message>
      <source>%1 playback device%2 detected. JGRF will use the system default.</source>
      <translation>재생 장치 %1개를 감지했습니다. JGRF는 시스템 기본 장치를 사용합니다.</translation>
    </message>
    <message>
      <source>%1-star rating</source>
      <translation>별점 %1점</translation>
    </message>
    <message>
      <source>5 stars</source>
      <translation>별 5개</translation>
    </message>
    <message>
      <source>ADPCM Accumulator Wrap</source>
      <translation>ADPCM 누산기 랩</translation>
    </message>
    <message>
      <source>AES (Console)</source>
      <translation>AES (가정용)</translation>
    </message>
    <message>
      <source>About</source>
      <translation>프로그램 정보</translation>
    </message>
    <message>
      <source>Alerts</source>
      <translation>알림</translation>
    </message>
    <message>
      <source>Alerts (%1)</source>
      <translation>알림 (%1)</translation>
    </message>
    <message>
      <source>Alternate title</source>
      <translation>다른 제목</translation>
    </message>
    <message>
      <source>Anti-Aliased Nearest Neighbour</source>
      <translation>앤티에일리어싱 최근접 이웃 보간</translation>
    </message>
    <message>
      <source>Any genre</source>
      <translation>모든 장르</translation>
    </message>
    <message>
      <source>Any playtime</source>
      <translation>모든 플레이 시간</translation>
    </message>
    <message>
      <source>Any rating</source>
      <translation>모든 평점</translation>
    </message>
    <message>
      <source>Aperture Grille</source>
      <translation>어퍼처 그릴</translation>
    </message>
    <message>
      <source>Aperture Grille Lite</source>
      <translation>어퍼처 그릴 (경량)</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>적용</translation>
    </message>
    <message>
      <source>Aspect Ratio</source>
      <translation>화면 비율</translation>
    </message>
    <message>
      <source>At least 1 star</source>
      <translation>별 1개 이상</translation>
    </message>
    <message>
      <source>At least 2 stars</source>
      <translation>별 2개 이상</translation>
    </message>
    <message>
      <source>At least 3 stars</source>
      <translation>별 3개 이상</translation>
    </message>
    <message>
      <source>At least 4 stars</source>
      <translation>별 4개 이상</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation>오디오</translation>
    </message>
    <message>
      <source>Audio CPU ROM</source>
      <translation>오디오 CPU ROM</translation>
    </message>
    <message>
      <source>Audio Status:</source>
      <translation>오디오 상태:</translation>
    </message>
    <message>
      <source>Audio sample ROM</source>
      <translation>오디오 샘플 ROM</translation>
    </message>
    <message>
      <source>Auto</source>
      <translation>자동</translation>
    </message>
    <message>
      <source>BIOS Folder</source>
      <translation>BIOS 폴더</translation>
    </message>
    <message>
      <source>Big Grid Icons</source>
      <translation>큰 아이콘</translation>
    </message>
    <message>
      <source>Browse...</source>
      <translation>찾아보기...</translation>
    </message>
    <message>
      <source>CD DMA Length Limit (Hack)</source>
      <translation>CD DMA 전송 길이 제한 (핵)</translation>
    </message>
    <message>
      <source>CD System</source>
      <translation>CD 시스템</translation>
    </message>
    <message>
      <source>CRTea Corner</source>
      <translation>CRTea 모서리 둥글기</translation>
    </message>
    <message>
      <source>CRTea Curve</source>
      <translation>CRTea 화면 곡률</translation>
    </message>
    <message>
      <source>CRTea Mask Strength</source>
      <translation>CRTea 마스크 강도</translation>
    </message>
    <message>
      <source>CRTea Mask Type</source>
      <translation>CRTea 마스크 종류</translation>
    </message>
    <message>
      <source>CRTea Mode</source>
      <translation>CRTea 모드</translation>
    </message>
    <message>
      <source>CRTea Scanline Strength</source>
      <translation>CRTea 주사선 강도</translation>
    </message>
    <message>
      <source>CRTea Shader</source>
      <translation>CRTea 셰이더</translation>
    </message>
    <message>
      <source>CRTea Sharpness</source>
      <translation>CRTea 선명도</translation>
    </message>
    <message>
      <source>CRTea Trinitron Curve</source>
      <translation>CRTea 트리니트론 곡률</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>취소</translation>
    </message>
    <message>
      <source>Capture game screenshot (3s)...</source>
      <translation>게임 화면 캡처 (3초 후)...</translation>
    </message>
    <message>
      <source>Cartridge</source>
      <translation>카트리지</translation>
    </message>
    <message>
      <source>Checking JGRF video capabilities...</source>
      <translation>JGRF 비디오 기능을 확인하는 중...</translation>
    </message>
    <message>
      <source>Clear active filters</source>
      <translation>필터 해제</translation>
    </message>
    <message>
      <source>Clear all</source>
      <translation>모두 지우기</translation>
    </message>
    <message>
      <source>Clear the %1-star rating</source>
      <translation>별점 %1점 해제</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>닫기</translation>
    </message>
    <message>
      <source>Collapse all</source>
      <translation>모두 접기</translation>
    </message>
    <message>
      <source>Command overlay</source>
      <translation>명령어 표시</translation>
    </message>
    <message>
      <source>Configure profile</source>
      <translation>프로필 설정</translation>
    </message>
    <message>
      <source>Core</source>
      <translation>코어</translation>
    </message>
    <message>
      <source>Could not play GIF</source>
      <translation>GIF를 재생할 수 없습니다</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>사용자 지정</translation>
    </message>
    <message>
      <source>Custom overrides</source>
      <translation>개별 설정 있음</translation>
    </message>
    <message>
      <source>Default</source>
      <translation>기본값</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>삭제</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>게임 설명</translation>
    </message>
    <message>
      <source>Detected Playback Devices:</source>
      <translation>감지된 재생 장치:</translation>
    </message>
    <message>
      <source>Detecting playback devices...</source>
      <translation>재생 장치를 감지하는 중...</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>사용 안 함</translation>
    </message>
    <message>
      <source>Enabled</source>
      <translation>사용</translation>
    </message>
    <message>
      <source>Expand all</source>
      <translation>모두 펼치기</translation>
    </message>
    <message>
      <source>Export...</source>
      <translation>내보내기...</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>즐겨찾기</translation>
    </message>
    <message>
      <source>Favorites only</source>
      <translation>즐겨찾기만</translation>
    </message>
    <message>
      <source>Filters</source>
      <translation>필터</translation>
    </message>
    <message>
      <source>Filters (%1)</source>
      <translation>필터 (%1)</translation>
    </message>
    <message>
      <source>Fixed-layer ROM</source>
      <translation>고정 레이어 ROM</translation>
    </message>
    <message>
      <source>Format</source>
      <translation>형식</translation>
    </message>
    <message>
      <source>Free Play (Only MVS)</source>
      <translation>프리플레이 (MVS 전용)</translation>
    </message>
    <message>
      <source>Frontend Log Unavailable</source>
      <translation>프론트엔드 로그를 열 수 없습니다</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>전체 화면</translation>
    </message>
    <message>
      <source>Gameplay Stats</source>
      <translation>플레이 기록</translation>
    </message>
    <message>
      <source>Genre</source>
      <translation>장르</translation>
    </message>
    <message>
      <source>Geolith Core Video</source>
      <translation>Geolith 코어 비디오</translation>
    </message>
    <message>
      <source>Global defaults</source>
      <translation>전체 기본값</translation>
    </message>
    <message>
      <source>Goliath shortcuts</source>
      <translation>Goliath 단축키</translation>
    </message>
    <message>
      <source>Graphics ROM</source>
      <translation>그래픽 ROM</translation>
    </message>
    <message>
      <source>Grid</source>
      <translation>그리드</translation>
    </message>
    <message>
      <source>History</source>
      <translation>이력</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation>단축키</translation>
    </message>
    <message>
      <source>Icons Folder</source>
      <translation>아이콘 폴더</translation>
    </message>
    <message>
      <source>Import...</source>
      <translation>가져오기...</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>정보</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>입력</translation>
    </message>
    <message>
      <source>Input Device</source>
      <translation>입력 장치</translation>
    </message>
    <message>
      <source>Integer Scaling</source>
      <translation>정수배 확대</translation>
    </message>
    <message>
      <source>JollyGood Audio Settings</source>
      <translation>JollyGood 오디오 설정</translation>
    </message>
    <message>
      <source>JollyGood Misc Settings</source>
      <translation>JollyGood 기타 설정</translation>
    </message>
    <message>
      <source>JollyGood Renderer / Window</source>
      <translation>JollyGood 렌더러 / 창</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>언어</translation>
    </message>
    <message>
      <source>Language (restart required)</source>
      <translation>언어 (다시 시작해야 적용)</translation>
    </message>
    <message>
      <source>Last Ended</source>
      <translation>마지막 종료 시각</translation>
    </message>
    <message>
      <source>Last Session</source>
      <translation>지난 플레이 시간</translation>
    </message>
    <message>
      <source>Last Started</source>
      <translation>마지막 실행 시각</translation>
    </message>
    <message>
      <source>Launch</source>
      <translation>실행</translation>
    </message>
    <message>
      <source>Launch Profile</source>
      <translation>실행 프로필</translation>
    </message>
    <message>
      <source>Launch random game (%1)</source>
      <translation>무작위 게임 실행 (%1)</translation>
    </message>
    <message>
      <source>Linear</source>
      <translation>선형 보간</translation>
    </message>
    <message>
      <source>List</source>
      <translation>목록</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>불러오는 중...</translation>
    </message>
    <message>
      <source>MVS (Arcade)</source>
      <translation>MVS (업소용)</translation>
    </message>
    <message>
      <source>Mahjong</source>
      <translation>마작</translation>
    </message>
    <message>
      <source>Main Data</source>
      <translation>기본 정보</translation>
    </message>
    <message>
      <source>Manufacturer</source>
      <translation>제작사</translation>
    </message>
    <message>
      <source>Mark all read</source>
      <translation>모두 읽음으로 표시</translation>
    </message>
    <message>
      <source>Mask Overscan (Bottom)</source>
      <translation>오버스캔 가리기 (아래)</translation>
    </message>
    <message>
      <source>Mask Overscan (Left)</source>
      <translation>오버스캔 가리기 (왼쪽)</translation>
    </message>
    <message>
      <source>Mask Overscan (Right)</source>
      <translation>오버스캔 가리기 (오른쪽)</translation>
    </message>
    <message>
      <source>Mask Overscan (Top)</source>
      <translation>오버스캔 가리기 (위)</translation>
    </message>
    <message>
      <source>Memory Card</source>
      <translation>메모리 카드</translation>
    </message>
    <message>
      <source>Memory Card Inserted</source>
      <translation>메모리 카드 삽입됨</translation>
    </message>
    <message>
      <source>Memory Card Write-Protected</source>
      <translation>메모리 카드 쓰기 금지</translation>
    </message>
    <message>
      <source>Metadata Folder</source>
      <translation>메타데이터 폴더</translation>
    </message>
    <message>
      <source>Metadata only</source>
      <translation>메타데이터만</translation>
    </message>
    <message>
      <source>Misc</source>
      <translation>기타</translation>
    </message>
    <message>
      <source>Mismatch</source>
      <translation>불일치</translation>
    </message>
    <message>
      <source>Name (A → Z)</source>
      <translation>이름 (가나다순)</translation>
    </message>
    <message>
      <source>Name (Z → A)</source>
      <translation>이름 (역순)</translation>
    </message>
    <message>
      <source>Neo Geo CD (Front Loader)</source>
      <translation>Neo Geo CD (프런트 로더)</translation>
    </message>
    <message>
      <source>Neo Geo CD (Top Loader)</source>
      <translation>Neo Geo CD (탑 로더)</translation>
    </message>
    <message>
      <source>Neo Geo CD Images</source>
      <translation>Neo Geo CD 이미지 폴더</translation>
    </message>
    <message>
      <source>Neo Geo Joysticks</source>
      <translation>Neo Geo 조이스틱</translation>
    </message>
    <message>
      <source>Neo Geo MVS/AES - ROMs: %1 - Parents: %2 - Variants: %3 - Homebrew: %4</source>
      <translation>Neo Geo MVS/AES - ROM: %1 - 부모 ROM: %2 - 변형: %3 - 홈브루: %4</translation>
    </message>
    <message>
      <source>Neo Geo MVS/AES ROMs</source>
      <translation>Neo Geo MVS/AES ROM 폴더</translation>
    </message>
    <message>
      <source>Never played</source>
      <translation>플레이한 적 없음</translation>
    </message>
    <message>
      <source>Next GIF</source>
      <translation>다음 GIF</translation>
    </message>
    <message>
      <source>No Mask</source>
      <translation>마스크 없음</translation>
    </message>
    <message>
      <source>No game selected</source>
      <translation>선택된 게임이 없습니다</translation>
    </message>
    <message>
      <source>No games match the current filters</source>
      <translation>현재 필터와 일치하는 게임이 없습니다</translation>
    </message>
    <message>
      <source>No matching games</source>
      <translation>일치하는 게임이 없습니다</translation>
    </message>
    <message>
      <source>No notifications</source>
      <translation>알림이 없습니다</translation>
    </message>
    <message>
      <source>None</source>
      <translation>없음</translation>
    </message>
    <message>
      <source>None / Nearest Neighbour</source>
      <translation>없음 / 최근접 이웃 보간</translation>
    </message>
    <message>
      <source>Not played yet</source>
      <translation>아직 플레이하지 않음</translation>
    </message>
    <message>
      <source>Notifications</source>
      <translation>알림</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>확인</translation>
    </message>
    <message>
      <source>Off</source>
      <translation>끔</translation>
    </message>
    <message>
      <source>On</source>
      <translation>켬</translation>
    </message>
    <message>
      <source>Open Folder</source>
      <translation>폴더 열기</translation>
    </message>
    <message>
      <source>Open Per-game Settings for the selected ROM or disc image</source>
      <translation>선택한 ROM 또는 디스크 이미지의 게임별 설정을 엽니다</translation>
    </message>
    <message>
      <source>Output Device</source>
      <translation>출력 장치</translation>
    </message>
    <message>
      <source>Output Device:</source>
      <translation>출력 장치:</translation>
    </message>
    <message>
      <source>Palette</source>
      <translation>팔레트</translation>
    </message>
    <message>
      <source>Parent ROM missing</source>
      <translation>부모 ROM 없음</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>경로</translation>
    </message>
    <message>
      <source>Pause GIF</source>
      <translation>GIF 일시정지</translation>
    </message>
    <message>
      <source>Per-game Settings</source>
      <translation>게임별 설정</translation>
    </message>
    <message>
      <source>Play GIF</source>
      <translation>GIF 재생</translation>
    </message>
    <message>
      <source>Played</source>
      <translation>플레이함</translation>
    </message>
    <message>
      <source>Players</source>
      <translation>플레이 인원</translation>
    </message>
    <message>
      <source>Playtime</source>
      <translation>플레이 시간</translation>
    </message>
    <message>
      <source>Playtime (Least → Most)</source>
      <translation>플레이 시간 (짧은 순)</translation>
    </message>
    <message>
      <source>Playtime (Most → Least)</source>
      <translation>플레이 시간 (긴 순)</translation>
    </message>
    <message>
      <source>Previous GIF</source>
      <translation>이전 GIF</translation>
    </message>
    <message>
      <source>Profile</source>
      <translation>프로필</translation>
    </message>
    <message>
      <source>Program ROM</source>
      <translation>프로그램 ROM</translation>
    </message>
    <message>
      <source>ROM regions</source>
      <translation>ROM 영역</translation>
    </message>
    <message>
      <source>Random</source>
      <translation>무작위</translation>
    </message>
    <message>
      <source>Rate:</source>
      <translation>평점:</translation>
    </message>
    <message>
      <source>Rated</source>
      <translation>평점 있음</translation>
    </message>
    <message>
      <source>Rating</source>
      <translation>평점</translation>
    </message>
    <message>
      <source>Rating (1 → 5)</source>
      <translation>평점 (낮은 순)</translation>
    </message>
    <message>
      <source>Rating (5 → 1)</source>
      <translation>평점 (높은 순)</translation>
    </message>
    <message>
      <source>Raw</source>
      <translation>원본</translation>
    </message>
    <message>
      <source>Record game GIF (3s)...</source>
      <translation>게임 GIF 녹화 (3초 후)...</translation>
    </message>
    <message>
      <source>Refresh Devices</source>
      <translation>장치 새로 고침</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>지역</translation>
    </message>
    <message>
      <source>Release</source>
      <translation>출시일</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>제거</translation>
    </message>
    <message>
      <source>Resampler Quality</source>
      <translation>리샘플러 품질</translation>
    </message>
    <message>
      <source>Rescan Error</source>
      <translation>다시 검색 오류</translation>
    </message>
    <message>
      <source>Rescan ROMs</source>
      <translation>ROM 다시 검색</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>초기화</translation>
    </message>
    <message>
      <source>Reset to Defaults</source>
      <translation>기본 설정으로 되돌리기</translation>
    </message>
    <message>
      <source>Resistor Network</source>
      <translation>저항 네트워크</translation>
    </message>
    <message>
      <source>Restart Goliath to apply the language and game title changes.</source>
      <translation>언어와 게임 제목 변경을 적용하려면 Goliath를 다시 시작하세요.</translation>
    </message>
    <message>
      <source>Resume GIF</source>
      <translation>GIF 재생 재개</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>저장</translation>
    </message>
    <message>
      <source>Save Audio Settings</source>
      <translation>오디오 설정 저장</translation>
    </message>
    <message>
      <source>Save Core Settings</source>
      <translation>코어 설정 저장</translation>
    </message>
    <message>
      <source>Save Input Settings</source>
      <translation>입력 설정 저장</translation>
    </message>
    <message>
      <source>Save Misc Settings</source>
      <translation>기타 설정 저장</translation>
    </message>
    <message>
      <source>Save Path Settings</source>
      <translation>경로 설정 저장</translation>
    </message>
    <message>
      <source>Save Settings</source>
      <translation>설정 저장</translation>
    </message>
    <message>
      <source>Save Video Settings</source>
      <translation>비디오 설정 저장</translation>
    </message>
    <message>
      <source>Scale (Initial)</source>
      <translation>시작 시 배율</translation>
    </message>
    <message>
      <source>Scanlines</source>
      <translation>주사선</translation>
    </message>
    <message>
      <source>Search games...</source>
      <translation>게임 검색...</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>검색...</translation>
    </message>
    <message>
      <source>Select a parent, variant, CUE, or CHD to rate it</source>
      <translation>평점을 매길 부모, 변형, CUE 또는 CHD를 선택하세요</translation>
    </message>
    <message>
      <source>Selected variant: </source>
      <translation>선택한 변형: </translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>제품 번호</translation>
    </message>
    <message>
      <source>Series</source>
      <translation>시리즈</translation>
    </message>
    <message>
      <source>Sessions</source>
      <translation>플레이 횟수</translation>
    </message>
    <message>
      <source>Setting Mode (Only MVS)</source>
      <translation>설정 모드 (MVS 전용)</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>설정</translation>
    </message>
    <message>
      <source>Shader</source>
      <translation>셰이더</translation>
    </message>
    <message>
      <source>Shadow Mask</source>
      <translation>섀도 마스크</translation>
    </message>
    <message>
      <source>Sharp Bilinear</source>
      <translation>샤프 바이리니어</translation>
    </message>
    <message>
      <source>Show variants</source>
      <translation>변형 표시</translation>
    </message>
    <message>
      <source>Snaps</source>
      <translation>스크린샷</translation>
    </message>
    <message>
      <source>Snapshots Folder</source>
      <translation>스크린샷 폴더</translation>
    </message>
    <message>
      <source>Sort</source>
      <translation>정렬</translation>
    </message>
    <message>
      <source>System</source>
      <translation>시스템</translation>
    </message>
    <message>
      <source>System Default (JGRF stock)</source>
      <translation>시스템 기본값 (표준 JGRF)</translation>
    </message>
    <message>
      <source>System Type</source>
      <translation>시스템 종류</translation>
    </message>
    <message>
      <source>System default</source>
      <translation>시스템 기본값</translation>
    </message>
    <message>
      <source>Technical Details</source>
      <translation>기술 정보</translation>
    </message>
    <message>
      <source>Tools</source>
      <translation>도구</translation>
    </message>
    <message>
      <source>Unidentified</source>
      <translation>식별되지 않음</translation>
    </message>
    <message>
      <source>Universe BIOS HW</source>
      <translation>Universe BIOS 하드웨어</translation>
    </message>
    <message>
      <source>Unrated</source>
      <translation>평점 없음</translation>
    </message>
    <message>
      <source>VSync</source>
      <translation>수직 동기화</translation>
    </message>
    <message>
      <source>Verification</source>
      <translation>검증</translation>
    </message>
    <message>
      <source>Verified</source>
      <translation>검증됨</translation>
    </message>
    <message>
      <source>Verify BIOS</source>
      <translation>BIOS 검증</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>비디오</translation>
    </message>
    <message>
      <source>Video API</source>
      <translation>렌더링 API</translation>
    </message>
    <message>
      <source>View</source>
      <translation>보기</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>볼륨</translation>
    </message>
    <message>
      <source>Volume:</source>
      <translation>볼륨:</translation>
    </message>
    <message>
      <source>Vulkan (Experimental)</source>
      <translation>Vulkan (실험적)</translation>
    </message>
    <message>
      <source>Window Scale</source>
      <translation>창 배율</translation>
    </message>
    <message>
      <source>Year</source>
      <translation>출시 연도</translation>
    </message>
    <message>
      <source>Year (Newest → Oldest)</source>
      <translation>출시 연도 (최신 순)</translation>
    </message>
    <message>
      <source>Year (Oldest → Newest)</source>
      <translation>출시 연도 (오래된 순)</translation>
    </message>
    <message>
      <source>⏱ Benchmark Selected Game...</source>
      <translation>⏱ 선택한 게임 벤치마크...</translation>
    </message>
    <message>
      <source>⚙ Per-game Settings...</source>
      <translation>⚙ 게임별 설정...</translation>
    </message>
    <message>
      <source>🎨 Theme:</source>
      <translation>🎨 테마:</translation>
    </message>
    <message>
      <source>🎵 Export Selected Audio WAV...</source>
      <translation>🎵 선택한 오디오를 WAV로 내보내기...</translation>
    </message>
    <message>
      <source>💾 Save Data Manager...</source>
      <translation>💾 세이브 데이터 관리...</translation>
    </message>
    <message>
      <source>📄 Export Diagnostic Report...</source>
      <translation>📄 진단 보고서 내보내기...</translation>
    </message>
    <message>
      <source>🔁 Convertor .zip to .neo (Lithogen)</source>
      <translation>🔁 ZIP을 .neo로 변환 (Lithogen)</translation>
    </message>
    <message>
      <source>🔄 Rescan ROMs (%1)</source>
      <translation>🔄 ROM 다시 검색 (%1)</translation>
    </message>
    <message>
      <source>🔍 Search games...</source>
      <translation>🔍 게임 검색...</translation>
    </message>
    <message>
      <source>🔍 Verify BIOS (%1)</source>
      <translation>🔍 BIOS 검증 (%1)</translation>
    </message>
    <message>
      <source>🩺 Diagnostics &amp; Logs...</source>
      <translation>🩺 진단 및 로그...</translation>
    </message>
    <message>
      <source>▶ Launch</source>
      <translation>▶ 실행</translation>
    </message>
    <message>
      <source>Launch selected game (%1)</source>
      <translation>선택한 게임 실행 (%1)</translation>
    </message>
    <message>
      <source>Random game</source>
      <translation>무작위 게임 실행</translation>
    </message>
    <message>
      <source>Focus search</source>
      <translation>검색창으로 이동</translation>
    </message>
    <message>
      <source>Launch selected game</source>
      <translation>선택한 게임 실행</translation>
    </message>
    <message>
      <source>Expand all variants</source>
      <translation>모든 변형 펼치기</translation>
    </message>
    <message>
      <source>Collapse all variants</source>
      <translation>모든 변형 접기</translation>
    </message>
    <message>
      <source>Clear search (while focused)</source>
      <translation>검색 지우기 (검색창 선택 시)</translation>
    </message>
    <message>
      <source>In-game capture</source>
      <translation>게임 중 화면 캡처</translation>
    </message>
    <message>
      <source>Record GIF (Experimental):</source>
      <translation>GIF 녹화 (실험적):</translation>
    </message>
    <message>
      <source>GIF duration:</source>
      <translation>GIF 녹화 시간:</translation>
    </message>
    <message>
      <source>Capture PNG:</source>
      <translation>PNG 캡처:</translation>
    </message>
    <message>
      <source>5 seconds</source>
      <translation>5초</translation>
    </message>
    <message>
      <source>7 seconds</source>
      <translation>7초</translation>
    </message>
    <message>
      <source>10 seconds</source>
      <translation>10초</translation>
    </message>
    <message>
      <source>Save Hotkeys</source>
      <translation>단축키 저장</translation>
    </message>
    <message>
      <source>Capture shortcuts updated.</source>
      <translation>캡처 단축키를 업데이트했습니다.</translation>
    </message>
    <message>
      <source>This single key will be consumed while the tracked game has focus.</source>
      <translation>추적 중인 게임에 포커스가 있는 동안에는 이 단일 키가 캡처에 사용되며 게임에는 입력되지 않습니다.</translation>
    </message>
    <message>
      <source>GIF and PNG cannot use the same shortcut.</source>
      <translation>GIF와 PNG에는 서로 다른 단축키를 지정하세요.</translation>
    </message>
    <message>
      <source>Use one key combination, not a sequence.</source>
      <translation>키 시퀀스가 아닌 하나의 키 조합을 지정하세요.</translation>
    </message>
    <message>
      <source>Use Ctrl, Alt, and Shift only; the Meta/Super key is reserved.</source>
      <translation>수정 키는 Ctrl, Alt, Shift만 사용할 수 있습니다. Meta/Super 키는 예약되어 있습니다.</translation>
    </message>
    <message>
      <source>Choose a letter, number, F1-F24, or common punctuation key.</source>
      <translation>영문자, 숫자, F1~F24 또는 일반적인 기호 키를 지정하세요.</translation>
    </message>
    <message>
      <source>Toggle Fullscreen/Windowed Mode</source>
      <translation>전체 화면/창 모드 전환</translation>
    </message>
    <message>
      <source>Toggle Audio Playback (Mute/Unmute)</source>
      <translation>오디오 음소거 전환</translation>
    </message>
    <message>
      <source>Pause / Resume</source>
      <translation>일시정지 / 재개</translation>
    </message>
    <message>
      <source>Soft Reset</source>
      <translation>소프트 리셋</translation>
    </message>
    <message>
      <source>Toggle Cheats</source>
      <translation>치트 전환</translation>
    </message>
    <message>
      <source>Misc Settings</source>
      <translation>기타 설정</translation>
    </message>
    <message>
      <source>Reset Misc Settings</source>
      <translation>기타 설정 초기화</translation>
    </message>
    <message>
      <source>Reset JGRF Misc settings to their defaults?</source>
      <translation>JGRF의 기타 설정을 기본값으로 되돌릴까요?</translation>
    </message>
    <message>
      <source>JollyGood Input Settings</source>
      <translation>JollyGood 입력 설정</translation>
    </message>
    <message>
      <source>Input Device:</source>
      <translation>입력 장치:</translation>
    </message>
    <message>
      <source>Capture from:</source>
      <translation>입력을 받을 장치:</translation>
    </message>
    <message>
      <source>Refresh</source>
      <translation>새로 고침</translation>
    </message>
    <message>
      <source>Axis Deadzone</source>
      <translation>스틱 데드존</translation>
    </message>
    <message>
      <source>Axis Deadzone:</source>
      <translation>스틱 데드존:</translation>
    </message>
    <message>
      <source>Save JGRF Input Settings</source>
      <translation>JGRF 입력 설정 저장</translation>
    </message>
    <message>
      <source>Mapping Help</source>
      <translation>버튼 할당 도움말</translation>
    </message>
    <message>
      <source>Advanced Input Settings</source>
      <translation>고급 입력 설정</translation>
    </message>
    <message>
      <source>Auto-activate Cheats at Boot</source>
      <translation>시작 시 치트 자동 활성화</translation>
    </message>
    <message>
      <source>Core Log Level</source>
      <translation>코어 로그 수준</translation>
    </message>
    <message>
      <source>Frontend Log Level</source>
      <translation>프론트엔드 로그 수준</translation>
    </message>
    <message>
      <source>Background Effects</source>
      <translation>배경 효과</translation>
    </message>
    <message>
      <source>OSD Font</source>
      <translation>화면 표시 글꼴</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>디버그</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>경고</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>오류</translation>
    </message>
    <message>
      <source>Shade</source>
      <translation>음영</translation>
    </message>
    <message>
      <source>Tea</source>
      <translation>차</translation>
    </message>
    <message>
      <source>Snow</source>
      <translation>눈</translation>
    </message>
    <message>
      <source>Mushrooms</source>
      <translation>버섯</translation>
    </message>
    <message>
      <source>Fire</source>
      <translation>불꽃</translation>
    </message>
    <message>
      <source>Danmaku</source>
      <translation>탄막</translation>
    </message>
    <message>
      <source>These fixed shortcuts are active only while the Goliath window has focus. They do not register global keys or interfere with a running game.</source>
      <translation>이 고정 단축키는 Goliath 창에 포커스가 있는 동안에만 작동합니다. 전역 키로 등록되지 않으며 실행 중인 게임의 조작에도 영향을 주지 않습니다.</translation>
    </message>
    <message>
      <source>Goliath capture shortcuts work while a game is running. Use a letter, number, function key or punctuation, with or without Ctrl/Alt/Shift. Single keys are active only while the game has focus and will not also reach the game. Clear a field to disable its shortcut. The PNG capture still has a Tools button. GIF recording is experimental and can behave differently across renderers and desktop sessions.</source>
      <translation>캡처 단축키는 게임이 실행 중일 때 사용할 수 있습니다. 영문자, 숫자, 기능 키 또는 기호 키를 필요에 따라 Ctrl, Alt, Shift와 조합해 지정하세요. 단일 키는 게임에 포커스가 있는 동안에만 작동하며 게임에는 입력되지 않습니다. 입력란을 비우면 해당 단축키가 비활성화됩니다. PNG 캡처는 도구 메뉴에서도 실행할 수 있습니다. GIF 녹화는 실험적 기능이므로 렌더링 방식과 데스크톱 환경에 따라 동작이 다를 수 있습니다.</translation>
    </message>
    <message>
      <source>Capture shortcuts were applied for this session but could not be saved.

</source>
      <translation>캡처 단축키가 이번 실행에는 적용되었지만 설정을 저장하지 못했습니다.

</translation>
    </message>
    <message>
      <source>Misc settings could not be saved as one transaction.

</source>
      <translation>기타 설정을 하나의 트랜잭션으로 저장하지 못했습니다.

</translation>
    </message>
    <message>
      <source>Misc defaults could not be saved as one transaction.

</source>
      <translation>기타 설정의 기본값을 하나의 트랜잭션으로 저장하지 못했습니다.

</translation>
    </message>
    <message>
      <source>Keyboard capture is always active. The selected SDL controller is captured alongside it.</source>
      <translation>키보드 입력은 항상 받습니다. 선택한 SDL 컨트롤러의 입력도 함께 받습니다.</translation>
    </message>
    <message>
      <source>JGRF analog-axis deadzone. Range 0-9; default 5. Higher values ignore more movement around the center of an analog axis.</source>
      <translation>JGRF 아날로그 스틱의 데드존입니다. 범위는 0~9이고 기본값은 5입니다. 값이 클수록 스틱 중심 부근의 움직임을 더 넓게 무시합니다.</translation>
    </message>
    <message>
      <source>Unmodified JGRF opens SDL's system-default playback device.
Goliath can show detected devices, but selecting a specific device
would require audio-output support inside JGRF itself.</source>
      <translation>표준 JGRF는 SDL의 시스템 기본 재생 장치를 사용합니다.
Goliath에서 감지된 장치를 표시할 수는 있지만, 특정 출력 장치를 선택하려면
JGRF 자체에서 해당 기능을 지원해야 합니다.</translation>
    </message>
    <message>
      <source>Goliath stores this volume and reapplies it to the JGRF audio session on each launch in Windows. JGRF itself is not modified.</source>
      <translation>이 볼륨을 저장하고, Windows에서 게임을 실행할 때마다 JGRF 오디오 세션에 다시 적용합니다. JGRF 자체는 수정하지 않습니다.</translation>
    </message>
    <message>
      <source>%1 is also used by JGRF: %2. This capture shortcut may take precedence while a game is running.</source>
      <translation>%1은(는) JGRF의 "%2"에서도 사용됩니다. 게임 실행 중에는 이 캡처 단축키가 우선될 수 있습니다.</translation>
    </message>
    <message>
      <source>Convert ZIP to .neo with Lithogen</source>
      <translation>Lithogen으로 ZIP을 .neo로 변환</translation>
    </message>
    <message>
      <source>Use a separately installed Lithogen executable to convert one ZIP or all ZIPs directly inside a folder. Goliath processes them one at a time and shows the result for every archive.</source>
      <translation>별도로 설치한 Lithogen 실행 파일을 사용하여 ZIP 하나 또는 폴더 바로 아래의 모든 ZIP을 .neo로 변환합니다. Goliath가 하나씩 처리하며 각 압축 파일의 결과를 표시합니다.</translation>
    </message>
    <message>
      <source>One ZIP</source>
      <translation>ZIP 하나</translation>
    </message>
    <message>
      <source>All ZIPs in a folder</source>
      <translation>폴더 안의 모든 ZIP</translation>
    </message>
    <message>
      <source>Choose folder</source>
      <translation>폴더 선택</translation>
    </message>
    <message>
      <source>Choose file</source>
      <translation>파일 선택</translation>
    </message>
    <message>
      <source>Lithogen executable:</source>
      <translation>Lithogen 실행 파일:</translation>
    </message>
    <message>
      <source>Executables (*.exe *);;All files (*)</source>
      <translation>실행 파일 (*.exe *);;모든 파일 (*)</translation>
    </message>
    <message>
      <source>Input ZIP:</source>
      <translation>입력 ZIP:</translation>
    </message>
    <message>
      <source>ZIP archives (*.zip);;All files (*)</source>
      <translation>ZIP 압축 파일 (*.zip);;모든 파일 (*)</translation>
    </message>
    <message>
      <source>ZIP folder:</source>
      <translation>ZIP 폴더:</translation>
    </message>
    <message>
      <source>Output directory:</source>
      <translation>출력 폴더:</translation>
    </message>
    <message>
      <source>ZIPs are read from the chosen folder only, without subfolders. Existing .neo files are skipped and never overwritten. Split clones can use their parent ZIP from that same folder automatically.</source>
      <translation>선택한 폴더 바로 아래의 ZIP만 읽습니다 (하위 폴더는 제외). 이미 존재하는 .neo 파일은 건너뛰며 덮어쓰지 않습니다. 분할 클론은 같은 폴더에 있는 부모 ZIP을 자동으로 사용할 수 있습니다.</translation>
    </message>
    <message>
      <source>Advanced options</source>
      <translation>고급 옵션</translation>
    </message>
    <message>
      <source>Strict CRC checks (--strict)</source>
      <translation>엄격한 CRC 검사 (--strict)</translation>
    </message>
    <message>
      <source>Treat ROM CRC mismatches as errors instead of warnings.</source>
      <translation>ROM CRC 불일치를 경고가 아닌 오류로 처리합니다.</translation>
    </message>
    <message>
      <source>Find split clone parent ZIP automatically</source>
      <translation>분할 클론의 부모 ZIP 자동 검색</translation>
    </message>
    <message>
      <source>Search beside a split clone ZIP for its parent ZIP. Turn off to pass --no-auto-parent to Lithogen.</source>
      <translation>분할 클론 ZIP과 같은 폴더에서 부모 ZIP을 찾습니다. 끄면 Lithogen에 --no-auto-parent를 전달합니다.</translation>
    </message>
    <message>
      <source>Choose additional parent ZIP</source>
      <translation>추가 부모 ZIP 선택</translation>
    </message>
    <message>
      <source>Extra parent ZIP (-p):</source>
      <translation>추가 부모 ZIP (-p):</translation>
    </message>
    <message>
      <source>Only for unusual split sets. Lithogen uses this ZIP in addition to the selected game ZIP.</source>
      <translation>특수한 분할 세트 전용입니다. 선택한 게임 ZIP에 더해 이 ZIP도 사용합니다.</translation>
    </message>
    <message>
      <source>e.g. kof2002</source>
      <translation>예: kof2002</translation>
    </message>
    <message>
      <source>Override the ROM set identifier when the ZIP filename is not the MAME set ID (--set). Leave empty for automatic identification.</source>
      <translation>ZIP 파일 이름이 MAME 세트 ID와 다를 때 ROM 세트 ID를 지정합니다 (--set). 비워 두면 자동으로 식별합니다.</translation>
    </message>
    <message>
      <source>Set ID override (--set):</source>
      <translation>세트 ID 지정 (--set):</translation>
    </message>
    <message>
      <source>The extra parent and set ID apply only to one ZIP. In folder mode, keep parent ZIPs in the chosen folder; Lithogen finds them for split clones automatically.</source>
      <translation>추가 부모 ZIP과 세트 ID는 ZIP 하나를 변환할 때만 적용됩니다. 폴더 단위로 변환할 때는 부모 ZIP도 같은 폴더에 두세요. Lithogen이 분할 클론에 필요한 부모 ZIP을 자동으로 찾습니다.</translation>
    </message>
    <message>
      <source>Ready to convert.</source>
      <translation>변환할 준비가 되었습니다.</translation>
    </message>
    <message>
      <source>%v / %m ZIPs checked</source>
      <translation>ZIP %m개 중 %v개 확인함</translation>
    </message>
    <message>
      <source>Result</source>
      <translation>결과</translation>
    </message>
    <message>
      <source>Convert</source>
      <translation>변환</translation>
    </message>
    <message>
      <source>Stop conversion</source>
      <translation>변환 중지</translation>
    </message>
    <message>
      <source>Could not start Lithogen: </source>
      <translation>Lithogen을 시작할 수 없습니다: </translation>
    </message>
    <message>
      <source>Could not start executable</source>
      <translation>실행 파일을 시작할 수 없습니다</translation>
    </message>
    <message>
      <source>Choose an executable Lithogen file.</source>
      <translation>실행 가능한 Lithogen 파일을 선택하세요.</translation>
    </message>
    <message>
      <source>Choose an existing output directory.</source>
      <translation>존재하는 출력 폴더를 선택하세요.</translation>
    </message>
    <message>
      <source>Cannot access the output directory.</source>
      <translation>출력 폴더에 접근할 수 없습니다.</translation>
    </message>
    <message>
      <source>Choose an existing ZIP folder.</source>
      <translation>존재하는 ZIP 폴더를 선택하세요.</translation>
    </message>
    <message>
      <source>This folder contains over 2000 ZIPs. Choose a smaller folder.</source>
      <translation>이 폴더에 ZIP이 2000개를 넘습니다. 더 작은 폴더를 선택하세요.</translation>
    </message>
    <message>
      <source>No .zip archives were found directly in this folder.</source>
      <translation>이 폴더 바로 아래에 .zip 압축 파일이 없습니다.</translation>
    </message>
    <message>
      <source>Choose one existing .zip archive.</source>
      <translation>존재하는 .zip 압축 파일을 하나 선택하세요.</translation>
    </message>
    <message>
      <source>The additional parent must be an existing .zip file.</source>
      <translation>추가 부모는 존재하는 .zip 파일이어야 합니다.</translation>
    </message>
    <message>
      <source>Use only ASCII letters, numbers and underscore for the set ID.</source>
      <translation>세트 ID에는 영문자, 숫자, 밑줄만 사용하세요.</translation>
    </message>
    <message>
      <source>Waiting</source>
      <translation>대기 중</translation>
    </message>
    <message>
      <source>Queued %1 ZIP(s).</source>
      <translation>ZIP %1개를 대기열에 추가했습니다.</translation>
    </message>
    <message>
      <source>Skipped: .neo already exists</source>
      <translation>건너뜀: .neo가 이미 있음</translation>
    </message>
    <message>
      <source>[%1/%2] Skipped %3: .neo already exists.
</source>
      <translation>[%1/%2] %3 건너뜀: .neo가 이미 있습니다.
</translation>
    </message>
    <message>
      <source>Converting %1 of %2: %3</source>
      <translation>변환 중 %1 / %2: %3</translation>
    </message>
    <message>
      <source>Converting...</source>
      <translation>변환 중...</translation>
    </message>
    <message>
      <source>
Stopping conversion...
</source>
      <translation>
변환을 중지하는 중...
</translation>
    </message>
    <message>
      <source>Canceled (check for partial output)</source>
      <translation>취소됨 (불완전한 출력 파일을 확인하세요)</translation>
    </message>
    <message>
      <source>
Canceled. Check the output folder for partial files.
</source>
      <translation>
취소되었습니다. 출력 폴더에 불완전한 파일이 있는지 확인하세요.
</translation>
    </message>
    <message>
      <source>Failed (exit %1)</source>
      <translation>실패 (종료 코드 %1)</translation>
    </message>
    <message>
      <source>
Failed (exit %1). See Lithogen output above.
</source>
      <translation>
실패했습니다 (종료 코드 %1). 위의 Lithogen 출력을 확인하세요.
</translation>
    </message>
    <message>
      <source>No nonempty .neo created</source>
      <translation>비어 있지 않은 .neo가 생성되지 않았습니다</translation>
    </message>
    <message>
      <source>
No nonempty .neo was found for this ZIP. The set may be unknown to Lithogen.
</source>
      <translation>
이 ZIP에 해당하는 비어 있지 않은 .neo 파일을 찾을 수 없습니다. Lithogen이 이 세트를 지원하지 않을 수 있습니다.
</translation>
    </message>
    <message>
      <source>Created</source>
      <translation>생성됨</translation>
    </message>
    <message>
      <source>
Created: </source>
      <translation>
생성됨: </translation>
    </message>
    <message>
      <source>Not started</source>
      <translation>처리 안 됨</translation>
    </message>
    <message>
      <source>Created: %1  |  Failed: %2  |  Existing: %3  |  Not started: %4</source>
      <translation>생성: %1  |  실패: %2  |  기존: %3  |  처리 안 됨: %4</translation>
    </message>
    <message>
      <source>
Select Rescan ROMs to refresh Goliath's MVS/AES library.
</source>
      <translation>
'ROM 다시 검색'을 선택하면 Goliath의 MVS/AES 라이브러리를 새로 고칠 수 있습니다.
</translation>
    </message>
    <message>
      <source>
To find these games, select this output directory as Goliath's MVS/AES ROM directory.
</source>
      <translation>
이 게임들을 표시하려면 이 출력 폴더를 Goliath의 MVS/AES ROM 폴더로 지정하세요.
</translation>
    </message>
  </context>
  <context>
    <name>QKeySequenceEdit</name>
    <message>
      <source>Press shortcut</source>
      <translation>단축키 입력</translation>
    </message>
    <message>
      <source>%1, ...</source>
      <translation>%1, …</translation>
    </message>
  </context>
</TS>