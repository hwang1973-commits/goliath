#include "catch2/catch.hpp"

#include "common/theme.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <set>
#include <string>
#include <utility>
#include <vector>

using goliath::Theme;
using goliath::all_themes;
using goliath::contrast_text_for;
using goliath::find_theme;
using goliath::generate_combo_popup_style;
using goliath::generate_theme_style;
using goliath::theme_selector_popup_text;

namespace {

int hex_value(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    if (value >= 'A' && value <= 'F') return value - 'A' + 10;
    return -1;
}

bool parse_rgb(const std::string& color, std::array<int, 3>& rgb) {
    if (color.size() != 7 || color.front() != '#') return false;
    for (std::size_t channel = 0; channel < rgb.size(); ++channel) {
        const int high = hex_value(color[1 + channel * 2]);
        const int low = hex_value(color[2 + channel * 2]);
        if (high < 0 || low < 0) return false;
        rgb[channel] = high * 16 + low;
    }
    return true;
}

double linear_channel(int value) {
    const double srgb = static_cast<double>(value) / 255.0;
    return srgb <= 0.04045
        ? srgb / 12.92
        : std::pow((srgb + 0.055) / 1.055, 2.4);
}

double luminance(const std::string& color) {
    std::array<int, 3> rgb{};
    if (!parse_rgb(color, rgb)) return -1.0;
    return
        0.2126 * linear_channel(rgb[0]) +
        0.7152 * linear_channel(rgb[1]) +
        0.0722 * linear_channel(rgb[2]);
}

double contrast_ratio(const std::string& first, const std::string& second) {
    const double first_luminance = luminance(first);
    const double second_luminance = luminance(second);
    if (first_luminance < 0.0 || second_luminance < 0.0) return 0.0;
    const double lighter = std::max(first_luminance, second_luminance);
    const double darker = std::min(first_luminance, second_luminance);
    return (lighter + 0.05) / (darker + 0.05);
}

std::array<std::string, 11> palette(const Theme& theme) {
    return {
        theme.bg_primary,
        theme.bg_secondary,
        theme.bg_tertiary,
        theme.bg_hover,
        theme.accent,
        theme.accent_hover,
        theme.success,
        theme.danger,
        theme.text_primary,
        theme.text_secondary,
        theme.border,
    };
}

bool valid_theme(const Theme& theme) {
    if (theme.key.empty()) return false;
    for (const std::string& color : palette(theme)) {
        std::array<int, 3> rgb{};
        if (!parse_rgb(color, rgb)) return false;
    }
    return true;
}

double minimum_role_contrast(const Theme& theme) {
    const std::array<std::string, 4> backgrounds = {
        theme.accent,
        theme.accent_hover,
        theme.success,
        theme.danger,
    };
    double minimum = 100.0;
    for (const std::string& background : backgrounds) {
        minimum = std::min(
            minimum,
            contrast_ratio(background, contrast_text_for(background)));
    }
    return minimum;
}

bool embeds_palette(const std::string& stylesheet, const Theme& theme) {
    for (const std::string& color : palette(theme)) {
        if (stylesheet.find(color) == std::string::npos) return false;
    }
    return true;
}

bool preserves_branch_tokens(const std::string& stylesheet) {
    return
        stylesheet.find("<<BRANCH_CLOSED>>") != std::string::npos &&
        stylesheet.find("<<BRANCH_OPEN>>") != std::string::npos &&
        stylesheet.find("<<BRANCH_CLOSED_SELECTED>>") != std::string::npos &&
        stylesheet.find("<<BRANCH_OPEN_SELECTED>>") != std::string::npos;
}

} // namespace

TEST_CASE("theme catalog exposes balanced dark and light palettes", "[theme]") {
    const std::vector<std::string> expected_keys = {
        "Dark Modern",
        "AMOLED Black",
        "Dracula",
        "Tokyo Night",
        "Nord",
        "Gruvbox Dark",
        "GitHub Dark",
        "Goliath Pearl",
        "Warm Ivory",
        "Arctic Blue",
        "Neo Geo Classic",
        "High Contrast Light",
        "Sakura Paper",
    };
    const auto& themes = all_themes();
    REQUIRE(themes.size() == expected_keys.size());

    std::set<std::string> keys;
    for (std::size_t index = 0; index < themes.size(); ++index) {
        INFO("theme=" << themes[index].key);
        CHECK(themes[index].key == expected_keys[index]);
        CHECK(keys.insert(themes[index].key).second);
        CHECK(valid_theme(themes[index]));
        CHECK((themes[index].border_radius >= 4 &&
               themes[index].border_radius <= 10));
    }
}

TEST_CASE("details panels use theme-aware raised cards",
          "[theme][details]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find("QFrame#details_header_card") !=
              std::string::npos);
        CHECK(stylesheet.find("QFrame#details_info_card") !=
              std::string::npos);
        CHECK(stylesheet.find("QFrame#snapshot_card") !=
              std::string::npos);
        CHECK(stylesheet.find("QTextEdit#details_description_card") !=
              std::string::npos);
        CHECK(stylesheet.find("QLabel#details_subsection_title") !=
              std::string::npos);
        CHECK(stylesheet.find("QFrame#details_info_vertical_divider") !=
              std::string::npos);
        CHECK(stylesheet.find("QFrame#details_info_horizontal_divider") !=
              std::string::npos);
        CHECK(stylesheet.find("QPushButton#profile_configure_btn") !=
              std::string::npos);
        CHECK(stylesheet.find(
            "QWidget#details_field_label {\n"
            "    background-color: transparent;\n"
            "    border: none;\n"
            "}") != std::string::npos);
        CHECK(stylesheet.find(
            "    background-color: " + theme.bg_secondary + ";\n") !=
              std::string::npos);
        CHECK(stylesheet.find(
            "    border: 1px solid " + theme.border + ";\n") !=
              std::string::npos);
        CHECK(stylesheet.find(
            "QFrame#details_header_card {\n"
            "    background-color: transparent;") == std::string::npos);
        CHECK(stylesheet.find("@card_highlight@") == std::string::npos);
        CHECK(stylesheet.find("@card_shadow@") == std::string::npos);
        CHECK(stylesheet.find("@divider_shadow@") == std::string::npos);
        CHECK(stylesheet.find("@divider_highlight@") == std::string::npos);
        CHECK(stylesheet.find("qlineargradient(") != std::string::npos);
        CHECK(stylesheet.find("rgba(") != std::string::npos);
    }
}

TEST_CASE("primary toolbar actions use borderless theme feedback",
          "[theme][toolbar]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find("QPushButton#tools_btn") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#alerts_btn") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#settings_btn") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#about_btn") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#filters_btn") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#random_btn") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#favorite_btn") != std::string::npos);
        CHECK(stylesheet.find("QWidget#toolbar_actions") !=
              std::string::npos);
        CHECK(stylesheet.find(
            "QWidget#toolbar_actions {\n"
            "    background-color: transparent;\n"
            "    border: none;\n"
            "}") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#update_available_indicator") !=
              std::string::npos);
        CHECK(stylesheet.find(
            "QPushButton#update_available_indicator {\n"
            "    color: " + theme.accent + ";\n") != std::string::npos);
        CHECK(stylesheet.find("QPushButton#tools_btn::menu-indicator") !=
              std::string::npos);
        CHECK(stylesheet.find("QPushButton#filters_btn::menu-indicator") !=
              std::string::npos);
        CHECK(stylesheet.find("QComboBox#theme_selector") !=
              std::string::npos);
        CHECK(stylesheet.find("QComboBox#sort_selector") ==
              std::string::npos);
        const std::string toolbar_card =
            "QFrame#toolbar_frame {\n"
            "    background-color: " + theme.bg_secondary + ";\n"
            "    border: 1px solid " + theme.border + ";\n"
            "    border-radius: " +
            std::to_string(theme.border_radius) + "px;\n";
        CHECK(stylesheet.find(toolbar_card) != std::string::npos);
        const std::string expected_selectors =
            "QComboBox#theme_selector {\n"
            "    background-color: " + theme.bg_tertiary + ";\n";
        CHECK(stylesheet.find(expected_selectors) != std::string::npos);
        CHECK(stylesheet.find("    background-color: transparent;\n"
                              "    border: none;\n") != std::string::npos);
        CHECK(stylesheet.find("    image: none;\n"
                              "    width: 0px;\n"
                              "    height: 0px;\n") != std::string::npos);
    }
}

TEST_CASE("notification center uses theme-aware actionable cards",
          "[theme][notifications]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find("QFrame#notification_card") !=
              std::string::npos);
        CHECK(stylesheet.find("notificationSeverity=\"error\"") !=
              std::string::npos);
        CHECK(stylesheet.find("QLabel#notification_new_badge") !=
              std::string::npos);
        CHECK(stylesheet.find("QPushButton#notification_primary_action") !=
              std::string::npos);
    }
}

TEST_CASE("gallery control containers preserve the patterned background",
          "[theme][gallery]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find(
            "QWidget#gallery_panel,\n"
            "QWidget#gallery_rail {\n"
            "    background-color: transparent;\n"
            "    border: none;\n") != std::string::npos);
        CHECK(stylesheet.find(
            "QSplitter#library_details_splitter,\n"
            "QSplitter#library_details_splitter::handle {\n"
            "    background-color: transparent;\n"
            "    border: none;\n") != std::string::npos);
    }
}

TEST_CASE("library icon styling does not leak into settings lists",
          "[theme][library-view]") {
    const std::string stylesheet = generate_theme_style(
        find_theme("Neo Geo Classic"));
    CHECK(stylesheet.find("QListWidget#library_icon_view {") !=
          std::string::npos);
    CHECK(stylesheet.find("QListWidget#library_icon_view::item {") !=
          std::string::npos);
    CHECK(stylesheet.find("\nQListWidget {") == std::string::npos);
    CHECK(stylesheet.find("\nQListWidget::item {") == std::string::npos);
    CHECK(stylesheet.find(
        "QStackedWidget#library_view_stack {\n"
        "    background-color: transparent;\n"
        "    border: none;\n"
        "}") != std::string::npos);
}

TEST_CASE("legacy and unknown theme keys resolve predictably", "[theme]") {
    CHECK(find_theme("One Dark Pro").key == "Tokyo Night");
    CHECK(find_theme("Monokai Pro").key == "Gruvbox Dark");
    CHECK(find_theme("missing theme").key == "Dark Modern");
    CHECK(find_theme("Sakura Paper").key == "Sakura Paper");
}

TEST_CASE("numeric steppers use embedded theme arrow controls",
          "[theme][spinbox]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find("QSpinBox::up-button") != std::string::npos);
        CHECK(stylesheet.find("QSpinBox::down-button") != std::string::npos);
        CHECK(stylesheet.find("<<SPIN_UP>>") != std::string::npos);
        CHECK(stylesheet.find("<<SPIN_DOWN>>") != std::string::npos);
        CHECK(stylesheet.find("    width: 18px;\n"
                              "    background-color: transparent;\n"
                              "    border: none;\n") != std::string::npos);
        CHECK(stylesheet.find("    padding: 4px 22px 4px 8px;\n") !=
              std::string::npos);
    }
}

TEST_CASE("generated theme styles use readable semantic contrast", "[theme]") {
    CHECK(contrast_text_for("#ffffff") == "#000000");
    CHECK(contrast_text_for("#000000") == "#ffffff");
    CHECK(contrast_text_for("invalid") == "#ffffff");

    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(minimum_role_contrast(theme) >= 4.5);
        CHECK(stylesheet.find('@') == std::string::npos);
        CHECK(preserves_branch_tokens(stylesheet));
        CHECK(embeds_palette(stylesheet, theme));
    }
}

TEST_CASE("disabled Launch button uses inactive theme colors", "[theme][launch]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        const std::string expected_rule =
            "QPushButton#launch_btn:disabled {\n"
            "    background-color: " + theme.bg_tertiary + ";\n"
            "    border-color: " + theme.border + ";\n"
            "    color: " + theme.text_secondary + ";\n"
            "}";
        const std::size_t disabled_rule = stylesheet.find(expected_rule);

        CHECK(disabled_rule != std::string::npos);
        CHECK(disabled_rule >
              stylesheet.find("QPushButton#launch_btn:hover"));
    }
}

TEST_CASE("frameless windows do not add an outer theme perimeter", "[theme]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find("QMainWindow#frameless_window") ==
              std::string::npos);
        CHECK(stylesheet.find("QDialog#frameless_window") ==
              std::string::npos);
    }
}

TEST_CASE("settings tab panes omit their redundant outer frame",
          "[theme][settings][game-profile]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find(
                  "QTabWidget#settings_tabs::pane,\n"
                  "QTabWidget#game_profile_tabs::pane {\n"
                  "    border: none;\n"
                  "}") != std::string::npos);

        const std::string generic_pane =
            "QTabWidget::pane {\n"
            "    border: 1px solid " + theme.border + ";";
        CHECK(stylesheet.find(generic_pane) != std::string::npos);
    }
}

TEST_CASE("generated scrollbars omit directional line buttons",
          "[theme][scrollbar]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find(
                  "QScrollBar::add-line:vertical,\n"
                  "QScrollBar::sub-line:vertical {\n"
                  "    height: 0px;") != std::string::npos);
        CHECK(stylesheet.find(
                  "QScrollBar::add-line:horizontal,\n"
                  "QScrollBar::sub-line:horizontal {\n"
                  "    width: 0px;") != std::string::npos);
        CHECK(stylesheet.find(
                  "QScrollBar::up-arrow:vertical,\n"
                  "QScrollBar::down-arrow:vertical,\n"
                  "QScrollBar::left-arrow:horizontal,\n"
                  "QScrollBar::right-arrow:horizontal") !=
              std::string::npos);
    }
}

TEST_CASE("input panels retain their theme-aware outer cards", "[theme]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string expected_panel =
            "QGroupBox#input_panel {\n"
            "    background-color: " + theme.bg_secondary + ";\n"
            "    border: 1px solid " + theme.border + ";\n"
            "    border-radius: 16px;\n"
            "}";
        const std::string expected_toggle =
            "QPushButton#input_section_toggle {\n"
            "    color: " + theme.text_secondary + ";\n"
            "    background-color: " + theme.bg_tertiary + ";";
        const std::string stylesheet = generate_theme_style(theme);
        CHECK(stylesheet.find(expected_panel) != std::string::npos);
        CHECK(stylesheet.find(expected_toggle) != std::string::npos);
        CHECK(stylesheet.find(
                  "QPushButton#input_section_toggle:checked {\n"
                  "    color: " + theme.accent + ";") != std::string::npos);
    }
}

TEST_CASE("About Goliath remains theme-aware across every palette", "[theme]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        const std::string expected_cards =
            "QFrame#about_identity_card,\n"
            "QFrame#about_information_card {\n"
            "    background-color: " + theme.bg_secondary + ";\n"
            "    border: 1px solid " + theme.border + ";\n"
            "    border-radius: 12px;\n"
            "}";
        const std::string expected_close =
            "QPushButton#about_close_button {\n"
            "    background-color: " + theme.accent + ";\n"
            "    border-color: " + theme.accent + ";\n"
            "    color: " + contrast_text_for(theme.accent) + ";";
        const std::string expected_body =
            "QLabel#about_body {\n"
            "    color: " + theme.text_primary + ";\n"
            "}";
        CHECK(stylesheet.find(expected_cards) != std::string::npos);
        CHECK(stylesheet.find(expected_close) != std::string::npos);
        CHECK(stylesheet.find(expected_body) != std::string::npos);
        CHECK(contrast_ratio(theme.bg_secondary, theme.text_primary) >= 4.5);
    }
}

TEST_CASE("rescan and BIOS summaries use semantic colors across every palette",
          "[theme][rescan][bios]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string stylesheet = generate_theme_style(theme);
        const std::string expected_cards =
            "QFrame#rescan_summary_card,\n"
            "QFrame#rescan_change_card,\n"
            "QFrame#bios_summary_card,\n"
            "QFrame#bios_metric_card,\n"
            "QFrame#bios_archive_row,\n"
            "QFrame#controller_profile_editor,\n"
            "QFrame#controller_profile_card,\n"
            "QFrame#controller_profile_empty {\n"
            "    background-color: " + theme.bg_secondary + ";\n"
            "    border: 1px solid " + theme.border + ";\n"
            "    border-radius: 12px;\n"
            "}";
        const std::string expected_problem =
            "QLabel#rescan_metric_problem {\n"
            "    color: " + theme.danger + ";\n"
            "    font-weight: 700;\n"
            "}";
        const std::string expected_bios_ready =
            "QLabel#bios_status_heading[biosStatus=\"ready\"],\n"
            "QFrame#bios_metric_card[biosMetric=\"ready\"] QLabel#bios_metric_value,\n"
            "QLabel#bios_archive_status[biosStatus=\"ready\"],\n"
            "QLabel#bios_member_status[biosStatus=\"ready\"] {\n"
            "    color: " + theme.success + ";\n"
            "}";
        const std::string expected_bios_problem =
            "QLabel#bios_status_heading[biosStatus=\"problem\"],\n"
            "QFrame#bios_metric_card[biosMetric=\"problem\"] QLabel#bios_metric_value,\n"
            "QLabel#bios_archive_status[biosStatus=\"problem\"],\n"
            "QLabel#bios_member_status[biosStatus=\"problem\"] {\n"
            "    color: " + theme.danger + ";\n"
            "}";
        const std::string expected_bios_optional =
            "QFrame#bios_metric_card[biosMetric=\"optional\"] QLabel#bios_metric_value,\n"
            "QLabel#bios_archive_status[biosStatus=\"optional\"],\n"
            "QLabel#bios_member_status[biosStatus=\"optional\"] {\n"
            "    color: " + theme.text_secondary + ";\n"
            "}";
        const std::string expected_bios_hover =
            "QFrame#bios_archive_row:hover,\n"
            "QFrame#bios_archive_row:focus {\n"
            "    border-color: " + theme.accent + ";\n"
            "}";
        const std::string expected_bios_transparency =
            "QWidget#bios_archive_scroll_contents,\n"
            "QWidget#bios_archive_header,\n"
            "QWidget#bios_member_row {\n"
            "    background-color: transparent;\n"
            "    border: none;\n"
            "}";
        CHECK(stylesheet.find(expected_cards) != std::string::npos);
        CHECK(stylesheet.find(expected_problem) != std::string::npos);
        CHECK(stylesheet.find(expected_bios_ready) != std::string::npos);
        CHECK(stylesheet.find(expected_bios_problem) != std::string::npos);
        CHECK(stylesheet.find(expected_bios_optional) != std::string::npos);
        CHECK(stylesheet.find(expected_bios_hover) != std::string::npos);
        CHECK(stylesheet.find(expected_bios_transparency) !=
              std::string::npos);
        CHECK(stylesheet.find(
                  "QFrame#controller_profile_card[profileCompatible=\"true\"] {\n"
                  "    border-left: 3px solid " + theme.accent + ";\n"
                  "}") != std::string::npos);
        CHECK(stylesheet.find(
                  "QLabel#controller_profile_status[profileStatus=\"success\"] {\n"
                  "    border-color: " + theme.success + ";\n"
                  "}") != std::string::npos);
        CHECK(stylesheet.find(
                  "QPushButton#controller_profile_delete_confirm {\n"
                  "    border-color: " + theme.danger + ";\n"
                  "    color: " + theme.danger + ";") !=
              std::string::npos);
    }
}

TEST_CASE("combo popup remains readable across every palette", "[theme]") {
    constexpr const char* popup_selector =
        "QAbstractItemView#theme_selector_popup";

    CHECK(generate_theme_style(all_themes().front()).find(popup_selector) ==
          std::string::npos);

    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string popup_style =
            generate_combo_popup_style(theme);
        CHECK(contrast_ratio(theme.bg_hover, theme.text_primary) >= 4.5);
        CHECK(popup_style.find('@') == std::string::npos);
        CHECK((popup_style.find("QWidget#combo_popup_container") !=
                   std::string::npos &&
               popup_style.find("QAbstractItemView") != std::string::npos &&
               popup_style.find("border: none") != std::string::npos));
        CHECK(popup_style.find(theme.bg_hover) != std::string::npos);
        CHECK(popup_style.find(theme.text_primary) != std::string::npos);
        CHECK(popup_style.find(theme.accent) != std::string::npos);
        CHECK(popup_style.find(contrast_text_for(theme.accent)) !=
              std::string::npos);
    }
}

TEST_CASE("theme selector popup delegate owns its foreground colors", "[theme]") {
    for (const Theme& theme : all_themes()) {
        INFO("theme=" << theme.key);
        const std::string normal =
            theme_selector_popup_text(theme, false);
        const std::string selected =
            theme_selector_popup_text(theme, true);
        CHECK(normal == theme.text_primary);
        CHECK(selected == contrast_text_for(theme.accent));
        CHECK((contrast_ratio(theme.bg_hover, normal) >= 4.5 &&
               contrast_ratio(theme.accent, selected) >= 4.5));
    }
}
