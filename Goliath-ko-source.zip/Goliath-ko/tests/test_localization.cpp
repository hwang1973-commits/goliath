#include "common/localization.hpp"
#include "ui/library_details_presentation.hpp"
#include "ui/library_view_logic.hpp"
#include "ui/capture_hotkeys.hpp"
#include <catch2/catch.hpp>
#include <QCoreApplication>
#include <QTranslator>

using namespace goliath;

TEST_CASE("Korean library swaps titles without changing the catalog or media", "[localization]") {
    Game game;
    game.name = "Metal Slug (NGM-2010)";
    game.display = "Metal Slug";
    game.main_rom = "mslug.neo";
    Rom parent;
    parent.file = *game.main_rom;
    parent.mame = "mslug";
    parent.main = true;
    parent.name = game.name;
    parent.alt_title = "메탈 슬러그";
    game.roms.push_back(parent);
    Rom clone = parent;
    clone.main = false;
    clone.file = "mslugh.neo";
    clone.mame = "mslugh";
    clone.name = "Metal Slug (AES)";
    clone.alt_title = "메탈 슬러그 (가정용)";
    game.roms.push_back(clone);

    const std::vector<Game> catalog{game};
    const auto ko = localizedLibrary(catalog, true);
    CHECK(ko[0].display == *parent.alt_title);
    CHECK(ko[0].name == *parent.alt_title);
    CHECK(ko[0].roms[0].alt_title == parent.name);
    CHECK(ko[0].roms[1].name == clone.alt_title);
    CHECK(ko[0].roms[1].alt_title == clone.name);
    CHECK(ko[0].main_rom == game.main_rom);
    CHECK(ko[0].roms[1].file == clone.file);
    CHECK(ko[0].roms[1].mame == clone.mame);
    CHECK(libraryGameListTitles(ko)[0] == *parent.alt_title);
    CHECK(libraryTileTitle(ko[0], &ko[0].roms[1]) == *clone.alt_title);
    const auto details = buildLibraryDetailsPresentation(ko[0], 0, parent.file, {}, nullptr, true);
    CHECK(details.title == QString::fromStdString(*parent.alt_title));
    CHECK(details.alternate_title.text == QString::fromStdString(*parent.name));
    const auto variantDetails = buildLibraryDetailsPresentation(
        ko[0], 1, clone.file, {}, nullptr, true);
    CHECK(variantDetails.title == QString::fromStdString(*clone.alt_title));
    CHECK(catalog[0].name == game.name);
    CHECK(catalog[0].roms[0].alt_title == parent.alt_title);
    CHECK(localizedLibrary(catalog, false)[0].display == game.display);
}

TEST_CASE("Korean titles fall back per media and never borrow a clone title", "[localization]") {
    Game game;
    game.name = "English title";
    game.display = "English title";
    Rom rom;
    rom.file = "clone.neo";
    rom.name = "English clone";
    rom.alt_title = "다른 제목";
    game.roms.push_back(rom);
    CHECK(localizedLibrary({game}, true)[0].display == game.display);
    game.roms[0].main = true;
    for (const auto& alternate : {std::optional<std::string>{},
                                 std::optional<std::string>{""},
                                 std::optional<std::string>{"  "}}) {
        game.roms[0].alt_title = alternate;
        const auto localized = localizedLibrary({game}, true);
        CHECK(localized[0].display == game.display);
        CHECK(localized[0].roms[0].name == rom.name);
    }
    game.system = "neogeocd";
    game.roms[0].alt_title = "CD 다른 제목";
    CHECK(localizedLibrary({game}, true)[0].display == "CD 다른 제목");
}

TEST_CASE("Explicit interface language overrides system locale", "[localization]") {
    Config config;
    config.set("UI", "language", "en");
    CHECK(interfaceLanguage(config) == "en");
    config.set("UI", "language", "ko");
    CHECK(interfaceLanguage(config) == "ko");
    config.set("UI", "language", "invalid");
    CHECK((interfaceLanguage(config) == "en" || interfaceLanguage(config) == "ko"));
}

TEST_CASE("Embedded Qt catalog translates UI strings and preserves placeholders", "[localization]") {
    int argc = 1;
    char name[] = "localization-test";
    char* argv[] = {name, nullptr};
    QCoreApplication app(argc, argv);
    QTranslator translator;
    REQUIRE(translator.load(":/i18n/goliath_ko.qm"));
    REQUIRE(app.installTranslator(&translator));
    CHECK(uiText("Settings") == QString::fromUtf8("설정"));
    CHECK(uiText("Misc") == QString::fromUtf8("기타"));
    CHECK(uiText("Save Hotkeys") == QString::fromUtf8("단축키 저장"));
    CHECK(QCoreApplication::translate("QKeySequenceEdit", "Press shortcut") ==
          QString::fromUtf8("단축키 입력"));
    QString hotkeyError;
    CHECK_FALSE(parseCaptureHotkey(QKeySequence("Ctrl+K, Ctrl+C"), &hotkeyError));
    CHECK(hotkeyError == QString::fromUtf8(
        "키 시퀀스가 아닌 하나의 키 조합을 지정하세요."));
    CHECK(uiText("Launch random game (%1)").arg("F5").contains("F5"));
    CHECK(uiText("untranslated message") == "untranslated message");
    app.removeTranslator(&translator);
    CHECK(uiText("Settings") == "Settings");
}
