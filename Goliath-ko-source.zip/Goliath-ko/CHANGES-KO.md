# Korean build — modification notice (derived from the Japanese integrated build)

Modified on 2026-11-13 and 2026-11-14, based on Goliath 0.41.1, upstream commit
`dbb17200c95b30b19d73fa8341216407ef5c6c17`.

This is an unofficial modified version. It is not an upstream Goliath release
and does not imply endorsement by epsx, the emulator authors or other licensors.
The original Goliath copyright notices remain intact. This modified Goliath
work is distributed under GNU GPL version 3 or, at your option, any later version.
See LICENSE. Third-party components retain their separate licenses.

Changes made for this distribution:

- Qt TS/QM Japanese interface translations and persistent language selection.
- Japanese presentation using each nonblank alternate title as the main title,
  retaining the original English title in the alternate-title field.
- Original catalog/media identities retained; both title forms are searchable.
- Portable detection and persistence of the bundled Lithogen executable path.
- r4: clearer in-application Qt copyright/license and modification notices;
  accompanying source distribution, license credits and package documentation.

The integrated distribution also packages separate, unmodified JGRF, Geolith,
Lithogen, shader and runtime-library files identified in PACKAGE-AUDIT.json.
The modified frontend source and patch are supplied in source/.
Rebuild Goliath with the CMake/Qt 6/SDL3 instructions in HOWTO.md and
translations/README.md. Executable build timestamps need not be identical.

For this distribution, source availability and third-party notices are described
in SOURCE-CODE.md and THIRD-PARTY-NOTICES.md alongside the executable.

## r5 — 2026-11-14

Translated the shortcut settings descriptions/actions/capture controls, standard
Qt shortcut placeholder, Misc tab and fields, validation/save messages and
additional input/audio labels. Key bindings, stored identifiers, numeric values
and emulator settings are unchanged.

## r6 — 2026-11-14

Localized the Lithogen integration dialog, advanced controls, file pickers,
validation, progress, results and Goliath-generated conversion messages.
Lithogen arguments, file handling and external CLI output remain unchanged.

## r7 — 2026-11-20 (Korean)

Replaced every Japanese string with Korean: the Qt catalog is now
`translations/goliath_ko.ts` / `goliath_ko.qm` (language code `ko`, selector
label "한국어"), the alternate titles in `metadata/neogeo.xml` and
`metadata/neocd.xml` were translated to Korean, and tests/docs were updated
accordingly. The compiled QM was generated without Qt Linguist and should be
regenerated with `lrelease` when possible. Config value `[UI] language=ko`.
