#pragma once

#include "hash_cache.hpp"

#include <utility>

namespace goliath {

// Persistent SHA-1 cache used by Neo Geo CD Redump BIN-track verification.
class Sha1Cache {
public:
    static Sha1Cache load(const std::filesystem::path& path);

    std::optional<std::string> file_sha1(
        const std::filesystem::path& file,
        std::uintmax_t size,
        const std::atomic<bool>* cancel = nullptr);

    void prune_untouched() { m_cache.prune_untouched(); }
    bool save() { return m_cache.save(); }

    const std::filesystem::path& path() const { return m_cache.path(); }
    std::size_t hits() const { return m_cache.hits(); }
    std::size_t calculated() const { return m_cache.calculated(); }
    std::size_t entries() const { return m_cache.entries(); }
    std::size_t pruned() const { return m_cache.pruned(); }

private:
    explicit Sha1Cache(HashCache cache) : m_cache(std::move(cache)) {}
    HashCache m_cache;
};

} // namespace goliath
