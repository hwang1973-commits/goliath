// info_tab.hpp — update preferences plus information about the exact
// JGRF/Geolith/JG components installed next to the frontend. Component probes
// are lazy/asynchronous so opening Settings is never blocked by executable or
// shared-library I/O.
#pragma once

#include <QString>
#include <QWidget>
#include <filesystem>

class QLabel;
class QProcess;
class QPushButton;
class QComboBox;

namespace goliath {

class Config;

class InfoTab : public QWidget {
    Q_OBJECT
public:
    InfoTab(std::filesystem::path jollygoodExe, Config& config,
            QWidget* parent = nullptr);

    // Called when the tab becomes visible. The first activation probes the
    // installed components; later activations reuse the result until Refresh.
    void activate();

private slots:
    void refresh();

private:
    void setupUi();
    void startJgrfProbe();
    void startCoreProbe();
    void startLithogenProbe();
    void probeLithogenVersion(const QString& argument);
    void finishJgrfProbe();
    void finishCoreProbe();
    void finishLithogenProbe();
    void updateRefreshState();
    void saveUpdatePreference();
    void checkUpdatesNow();
    void refreshLastUpdateCheck();

    std::filesystem::path m_jollygoodExe;
    Config& m_config;

    QComboBox* m_updateInterval = nullptr;
    QLabel* m_lastUpdateCheck = nullptr;
    QLabel* m_updatePreferenceStatus = nullptr;
    QPushButton* m_checkUpdatesButton = nullptr;

    QLabel* m_jgrfVersion = nullptr;
    QLabel* m_jgrfExecutable = nullptr;
    QLabel* m_vulkanRenderer = nullptr;
    QLabel* m_esBgraRenderer = nullptr;
    QLabel* m_geolithVersion = nullptr;
    QLabel* m_coreLibrary = nullptr;
    QLabel* m_neocdFormats = nullptr;
    QLabel* m_chdSupport = nullptr;
    QLabel* m_jgApiVersion = nullptr;
    QLabel* m_lithogenVersion = nullptr;
    QLabel* m_lithogenExecutable = nullptr;
    QLabel* m_lithogenAvailability = nullptr;
    QLabel* m_status = nullptr;
    QPushButton* m_refreshButton = nullptr;

    QProcess* m_jgrfProcess = nullptr;
    QProcess* m_lithogenProcess = nullptr;
    bool m_activated = false;
    bool m_jgrfPending = false;
    bool m_corePending = false;
    bool m_lithogenPending = false;
    bool m_jgrfProbeOk = false;
    bool m_coreProbeOk = false;
    bool m_esBgraPairVerified = false;
    QString m_jgrfError;
    QString m_coreError;
};

} // namespace goliath
