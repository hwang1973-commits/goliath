// main_window.hpp — the main application window: custom title bar, themed
// toolbar, game library (tree, search, exact-media personal and Genre filters,
// Favorites, sort, show-variants), the details/snapshot panel, theme switching,
// launching or benchmarking a ROM via jollygood, an optional PID-bound
// command.dat companion, exact-media playtime observation, safe save-data
// management, one-shot WAV audio export, Settings, About, ROM rescan, and BIOS
// verification.

#pragma once

#include <QMainWindow>
#include <QByteArray>
#include <QPoint>
#include <QPixmap>
#include <QString>
#include <QStringList>
#include <QtCore/qnamespace.h>
#include <QtGlobal>

#include <array>
#include <cstdint>
#include <filesystem>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "game/detached_process_tracker.hpp"
#include "game/command_dat.hpp"
#include "game/game_library_state.hpp"
#include "game/game_model.hpp"
#include "game/game_playtime.hpp"
#include "game/game_profile.hpp"
#include "common/goliath_common.hpp"
#include "common/notification_store.hpp"
#include "common/paths.hpp"
#include "ui/library_view_logic.hpp"
#include "ui/command_dialog.hpp"
#include "update/release_feed.hpp"

class QCloseEvent;
class QEvent;
class QResizeEvent;
class QSplitter;
class QScrollArea;
class QComboBox;
class QListWidget;
class QListWidgetItem;
class QStackedWidget;
class QTreeWidget;
class QTreeWidgetItem;
class QLineEdit;
class QLabel;
class QTextEdit;
class QPushButton;
class QAction;
class QActionGroup;
class QMenu;
class QTimer;
class QMovie;
class QKeySequence;
class QHBoxLayout;
class QVBoxLayout;

namespace goliath {

class LibraryTileDelegate;
struct JollygoodLaunchPreparation;
struct RescanReport;

class TitleBar;
class RescanWorker;
#if defined(GOLIATH_WAYLAND_CAPTURE)
class WaylandGifHotkey;
#endif
#if defined(GOLIATH_X11_CAPTURE)
class X11GifHotkey;
#endif

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(Config config, QWidget* parent = nullptr);
    ~MainWindow() override;

protected:
    void changeEvent(QEvent* event) override;
    bool event(QEvent* e) override;
    void closeEvent(QCloseEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
#if defined(_WIN32)
    bool nativeEvent(const QByteArray& eventType, void* message,
                     qintptr* result) override;
#endif

private slots:
    void onSortChanged();
    void onShowVariantsChanged(bool checked);
    void onCommandOverlayChanged(bool checked);
    void onFavoritesOnlyChanged(bool checked);
    void toggleSelectedFavorite(bool favorite);
    void setSelectedRating(int rating);
    void updateSelection();
    void filterGames(const QString& text);
    void launchSelected();
    void launchSelectedItem(QTreeWidgetItem* item, int column);
    void openGameSettings();
    void showVerificationDetails();
    void manageSaveData();
    void benchmarkSelected();
    void verifySelectedGameIntegrity();
    void exportSelectedAudio();
    void captureGameScreenshot();
    void recordGameGifAfter(int delayMs);
    void exportDiagnosticReport();
    void openLogging();
    void openAbout();
    void focusSearch();
    void expandAll();
    void collapseAll();
    void launchRandomGame();
    void openRomFolder();
    void openSnapshotFolder();
    void openGameConfigFolder();
    void showTreeContextMenu(const QPoint& pos);

    void openSettings();
    void rescanRoms();
    void onRescanFinished(const RescanReport& report);
    void onRescanError(QString msg);
    void verifyBios();
    void openNotificationCenter();

private:
    void buildUi();
    void buildToolbar(QVBoxLayout* mainLayout);
    void buildToolbarFilters(QHBoxLayout* toolbar);
    void buildToolbarTools(QHBoxLayout* toolbar);
    void buildLibraryWorkspace(QVBoxLayout* mainLayout);
    void buildLibraryPanel();
    QWidget* buildDetailsHeaderCard();
    QWidget* buildDetailsInfoCard();
    QWidget* buildDetailsGalleryPanel();
    void buildDetailsDescription(QVBoxLayout* detailsLayout);
    void buildDetailsPanel();
    void updateDetailsLayoutMode();
    void buildStatusBar();
    void setupKeyboardShortcuts();
    // Apply a built-in theme by key; unknown keys fall back to Dark Modern.
    void applyTheme(const QString& themeName);
    void loadGames();
    // Returns indices into m_games.
    std::vector<int> sortedGameOrder(
        const std::vector<std::string>& listTitles) const;
    void populateTree();
    void refreshLibraryListRowBackgrounds();
    void refreshLibraryView(bool preserveSelection,
                            const QString& preferredRomOverride = {});
    void setAllGroupsExpanded(bool expanded);
    void setRatingFilter(LibraryRatingFilter filter);
    void setPlaytimeFilter(LibraryPlaytimeFilter filter);
    void setGenreFilter(const std::string& genre);
    void rebuildGenreFilterMenu();
    void clearLibraryFilters();
    void updateFiltersButton();
    void setLibraryDisplayMode(LibraryDisplayMode mode, bool persist = true);
    void updateIconViewGridSize();
    void refreshIconView();
    void syncIconSelectionFromTree();
    void selectIconItem(QListWidgetItem* item);
    void showIconContextMenu(const QPoint& pos);
    void showLibraryContextMenu(QTreeWidgetItem* item,
                                const QPoint& globalPos,
                                bool allowExpansionActions);
    void selectFirstSortedResult();
    bool mediaMatchesPersonalFilters(const Game& game,
                                     const std::string& media) const;
    std::int64_t mediaPlaytimeSeconds(const Game& game,
                                      const std::string& media) const;
    std::int64_t gameSortMetric(const Game& game, bool ratingMetric) const;
    std::vector<int> sortedVariantOrder(const Game& game) const;
    void setLibrarySystem(const std::string& system);
    void clearDetailsForNoSelection(bool filtered);
    void ensureVisibleSelection(bool filtered);
    void setSelectionActionsEnabled(bool enabled);
    void updateRatingButtons(int rating, bool enabled);
    void updateStatus();
    void centerWindow();
    void refreshResolvedPaths();
    void startAutomaticUpdateCheckIfDue();
    void reloadCachedUpdateAlert();
    void updateAvailableIndicator();
    void openAvailableUpdate();
    void loadNotifications();
    void saveNotifications();
    void addNotification(AppNotification notification);
    void removeNotification(const std::string& id);
    void updateNotificationsButton();
    void performNotificationAction(NotificationAction action);
    void loadGameProfiles();
    void loadGamePlaytime();
    void loadGameLibraryState();
    void saveGamePlaytime();
    bool trackGameProcess(qint64 pid, const std::string& system,
                          const std::string& media,
                          const QString& displayName,
                          const JollygoodLaunchPreparation& preparation,
                          std::uintmax_t logOffset);
    void openCommandCompanion(
        qint64 pid, const QString& gameTitle,
        const std::vector<std::string>& lookupIds);
    void closeCommandCompanion(std::int64_t pid);
    void refreshCommandCatalog();
    bool hasCommands(const Game& game, int romIndex) const;
    void updateScreenshotAction();
    void registerScreenshotHotkey();
    bool applyCaptureHotkeys(const QKeySequence& gif,
                             const QKeySequence& png, QString* error);
    void updateBareCaptureHotkeys();
    void captureGameScreenshotAfter(int delayMs);
    void recordGameGif();
#if defined(GOLIATH_WAYLAND_CAPTURE)
    void recordWaylandGameGif();
#endif
    void pollTrackedGameProcesses();
    void finishTrackedGameSessions();
    bool hasActiveTrackedGameProcess() const;
    QString resolveSnapshot(const std::string& shortName, const std::string& parentShort = "") const;
    void loadSnapshotFor(QString path, const std::string& shortFallback = "",
                         const std::string& recordingMedia = "");
    void refreshGameGallery();
    void stopGalleryMovie();
    void showGalleryItem();
    QString selectedRomFile() const;   // bare filename of the currently selected rom, used for persistence
    QString selectedRomPath() const;   // full path of the currently selected rom, used for "Open ROM folder"
    void rememberCurrentLibrarySelection();
    void rememberCurrentLibraryListViewport();
    void restoreCurrentLibraryListViewport();
    void restoreSelection(const QString& preferredRom = {});
    void launchItem(QTreeWidgetItem* item);
    void revealInExplorer(const QString& path);

    // --- launch pipeline: resolves jollygood, ensures BIOS/config are in
    // place, then starts the emulator process for the selected cartridge/CD
    // media using the correct configured root and JGRF system arguments. ---
    void launchMedia(const QString& mediaFile, const std::string& system,
                     const GameLaunchProfile* profile = nullptr,
                     std::optional<std::filesystem::path> waveOutputPath =
                         std::nullopt,
                     std::vector<std::string> commandLookupIds = {},
                     QString commandTitle = {});
    // Warn if the BIOS folder or expected archives are missing. The warning
    // is non-blocking; the user can still proceed.
    void warnIfBiosMissing();
    Config m_config;
    std::filesystem::path m_romDir;
    std::filesystem::path m_neocdDir;
    std::filesystem::path m_snapDir;
    AppPaths m_paths;
    bool m_japaneseLibrary = false;
    std::vector<Game> m_catalogGames;
    std::vector<Game> m_games; // Language-specific presentation copy.
    GameProfileStore m_gameProfiles;
    GamePlaytimeStore m_gamePlaytime;
    GameLibraryStateStore m_gameLibraryState;
    NotificationStore m_notifications;
    bool m_gamePlaytimePersistenceAvailable = true;
    bool m_gameLibraryStatePersistenceAvailable = true;
    bool m_notificationPersistenceAvailable = true;
    bool m_automaticUpdateCheckPending = false;
    std::optional<PublishedRelease> m_availableUpdate;
    // Diagnostics toggle for this Goliath session only. It is intentionally
    // absent from goliath.ini and exact-media profiles.
    bool m_verboseJgrfLogging = false;
    std::vector<std::unique_ptr<DetachedProcessTracker>>
        m_trackedGameProcesses;
    std::map<std::int64_t, std::unique_ptr<CommandDialog>> m_commandDialogs;
    CommandDatCatalog m_commandCatalog;
    std::filesystem::path m_commandCatalogPath;
    std::optional<std::filesystem::file_time_type> m_commandCatalogWriteTime;
    std::optional<std::uintmax_t> m_commandCatalogSize;
    bool m_commandCatalogLoaded = false;
    QTimer* m_playtimeTimer = nullptr;
    bool m_closeRequested = false;
    bool m_exitWhenTrackedProcessesFinish = false;
    bool m_screenshotHotkeyRegistered = false;
    bool m_pngHotkeyRegistered = false;
#if defined(GOLIATH_WAYLAND_CAPTURE)
    std::shared_ptr<WaylandGifHotkey> m_waylandGifHotkey;
#endif
#if defined(GOLIATH_X11_CAPTURE)
    std::shared_ptr<X11GifHotkey> m_x11GifHotkey;
#endif
    QString m_gifCaptureShortcut;
    QString m_pngCaptureShortcut;
    bool m_gifRecording = false;

    QString m_sortKey = "display";
    bool m_showVariants = true;
    bool m_commandOverlayEnabled = true;
    bool m_favoritesOnly = false;
    LibraryRatingFilter m_ratingFilter = LibraryRatingFilter::Any;
    LibraryPlaytimeFilter m_playtimeFilter = LibraryPlaytimeFilter::Any;
    std::string m_genreFilter;
    LibraryDisplayMode m_libraryDisplayMode = LibraryDisplayMode::List;
    bool m_rebuildingLibraryView = false;
    std::string m_librarySystem = "neogeo";
    LibraryListViewportMemory m_libraryListViewportMemory;

    TitleBar* m_titleBar = nullptr;
    QComboBox* m_themeCombo = nullptr;
    QPushButton* m_filtersButton = nullptr;
    QPushButton* m_updateAvailableButton = nullptr;
    QPushButton* m_notificationsButton = nullptr;
    QActionGroup* m_sortGroup = nullptr;
    QActionGroup* m_libraryDisplayGroup = nullptr;
    QActionGroup* m_ratingFilterGroup = nullptr;
    QActionGroup* m_playtimeFilterGroup = nullptr;
    QMenu* m_genreFilterMenu = nullptr;
    QAction* m_clearFiltersAction = nullptr;
    QAction* m_rescanAction = nullptr;
    QAction* m_screenshotAction = nullptr;
    QAction* m_gifAction = nullptr;

    QPushButton* m_mvsAesButton = nullptr;
    QPushButton* m_cdButton = nullptr;
    QTreeWidget* m_tree = nullptr;
    QStackedWidget* m_libraryViewStack = nullptr;
    QListWidget* m_iconView = nullptr;
    LibraryTileDelegate* m_libraryTileDelegate = nullptr;
    QLineEdit* m_searchEntry = nullptr;
    std::vector<QAction*> m_selectionActions;
    QLabel* m_libraryStatusLabel = nullptr;
    QPushButton* m_launchButton = nullptr;

    QScrollArea* m_detailsScroll = nullptr;
    QHBoxLayout* m_detailsMediaLayout = nullptr;
    QWidget* m_detailsInfoCard = nullptr;
    QWidget* m_detailsGalleryPanel = nullptr;
    bool m_detailsMediaStacked = false;
    QLabel* m_snapshotLabel = nullptr;
    QPushButton* m_gallerySnaps = nullptr;
    QPushButton* m_galleryGifs = nullptr;
    QPushButton* m_galleryPrevious = nullptr;
    QPushButton* m_galleryPlay = nullptr;
    QPushButton* m_galleryNext = nullptr;
    QLabel* m_galleryCountLabel = nullptr;
    QMovie* m_galleryMovie = nullptr;
    QPixmap m_gallerySnapshot;
    QString m_gallerySnapshotPath;
    QString m_galleryRomId;
    QString m_galleryRecordingId;
    QStringList m_galleryGifPaths;
    int m_galleryIndex = 0;
    QLabel* m_detailsTitleLabel = nullptr;
    QPushButton* m_favoriteButton = nullptr;
    QPushButton* m_gameSettingsButton = nullptr;
    std::array<QPushButton*, 5> m_ratingButtons{};
    QLabel* m_variantLabel = nullptr;
    std::map<std::string, QLabel*> m_infoLabels;
    std::map<std::string, QLabel*> m_infoFieldNameLabels;
    std::map<std::string, QWidget*> m_infoFieldLabels;
    QTextEdit* m_historyText = nullptr;
    QString m_detailsSelectionKey;
    RescanWorker* m_rescanWorker = nullptr;

    QSplitter* m_splitter = nullptr;
    bool m_detailsCollapsed = false;
    double m_savedSplitterRatio = 0.0;
};

} // namespace goliath
