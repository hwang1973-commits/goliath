#include "ui/settings_dialog.hpp"
#include "ui/application_shortcuts.hpp"
#include "ui/capture_hotkeys.hpp"
#include "ui/controller_profiles_dialog.hpp"

#include "common/file_transaction.hpp"
#include "common/goliath_common.hpp"
#include "common/qt_path.hpp"
#include "common/localization.hpp"
#include "common/theme.hpp"
#include "ui/tabs/audio_tab.hpp"
#include "ui/tabs/core_tab.hpp"
#include "ui/tabs/misc_tab.hpp"
#include "ui/tabs/info_tab.hpp"
#include "ui/widgets/engraved_controls.hpp"
#include "ui/widgets/title_bar.hpp"
#include "ini/ini_document.hpp"
#include "input/input_maps.hpp"
#include "ui/widgets/input_panel_widgets.hpp"
#include "input/joystick_listener.hpp"
#include "input/sdl_joystick.hpp"
#include "ui/tabs/video_tab.hpp"

#include <QAction>
#include <QCloseEvent>
#include <QComboBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QGuiApplication>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QKeyEvent>
#include <QKeySequence>
#include <QKeySequenceEdit>
#include <QLabel>
#include <QGroupBox>
#include <QLineEdit>
#include <QMenu>
#include <QMessageBox>
#include <QPushButton>
#include <QScrollArea>
#include <QScrollBar>
#include <QSpinBox>
#include <QTabWidget>
#include <QTimer>
#include <QVBoxLayout>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <utility>

namespace fs = std::filesystem;

namespace goliath {

namespace {

constexpr int kDefaultAxisDeadzone = 5;

void setOptionalNote(QLabel* label, const QString& text) {
    if (!label) return;
    label->setText(text);
    label->setVisible(!text.isEmpty());
}

void prepare_jgrf_input_documents(const AppPaths& paths, int deadzone,
                                  IniDocument& settings,
                                  IniDocument& core) {
    settings.load(paths.jollygood_settings_ini);
    settings.set("input", "axis_deadzone", std::to_string(deadzone));

    // Keep settings.ini canonical for frontend settings. A stale core
    // [input] override would otherwise silently win at the next JGRF launch.
    core.load(paths.geolith_ini);
    core.remove_section("input");
}

void restore_scroll_position_later(QScrollArea* scroll, int position) {
    if (!scroll) return;
    QTimer::singleShot(0, scroll, [scroll, position]() {
        scroll->verticalScrollBar()->setValue(position);
    });
}

const std::vector<std::pair<int, QString>>& inputDeviceOptions() {
    static const std::vector<std::pair<int, QString>> opts = {
        {1, "Neo Geo Joysticks"},
        {2, "Mahjong"},
        {3, "4-Player (AS/JP MVS)"},
        {4, "V-Liner"},
        {5, "Irritating Maze"},
    };
    return opts;
}

// (label, config key, is_file) — user-facing folders only. "database"
// (games.json location), "config" (jollygood/geolith.ini location) and
// "jollygood" (frontend executable) are deliberately not exposed here: the
// Video/Core/Input tabs hardcode the "geolith" ini schema and the
// "<config>/jollygood/" subfolder layout regardless of what these would be
// set to, so letting users redirect them here would be misleading.
// The database scanner reads its metadata files from the resolved Metadata
// Folder. Neo Geo cartridge and Neo Geo CD media folders are intentionally
// separate because CD sets are normally organized recursively.
struct PathSetting { const char* label; const char* key; };
const std::vector<PathSetting>& pathSettings() {
    static const std::vector<PathSetting> settings = {
        {"Neo Geo MVS/AES ROMs", "roms"},
        {"Neo Geo CD Images", "neocd"},
        {"Icons Folder", "icons"},
        {"Snapshots Folder", "snaps"},
        {"Metadata Folder", "metadata"},
        {"BIOS Folder", "bios"},
    };
    return settings;
}

// True if every key a visual input panel widget would show is also a valid
// key for this ini section per input_defs() (i.e. the panel is a safe fit).
bool keysSubsetOfInputDefs(const QStringList& widgetKeys, const std::string& section) {
    auto it = input_defs().find(section);
    if (it == input_defs().end()) return false;
    const auto& defKeys = it->second;
    for (const QString& k : widgetKeys) {
        if (std::find(defKeys.begin(), defKeys.end(), k.toStdString()) == defKeys.end()) return false;
    }
    return true;
}

QString inputMappingTooltip(const QString& stored) {
    const QString shownValue = stored.isEmpty() ? "not set" : stored;
    QString text = QString("Stored value: %1").arg(shownValue);

    if (!stored.isEmpty()) {
        auto action = jgrf_hotkey_action_for_binding(stored.toStdString());
        if (action.has_value()) {
            text += QString::fromUtf8(
                "\n\n\xE2\x9A\xA0 JGRF frontend hotkey: %1"
                "\nThis keyboard key also triggers a JGRF frontend action while hotkeys are enabled."
                "\n\nPress Shift+Tab in JGRF to toggle frontend hotkey processing.")
                .arg(QString::fromStdString(*action));
        }
    }

    return text;
}
} // namespace

SettingsDialog::SettingsDialog(Config& config, AppPaths paths,
                               HotkeyApply applyHotkeys, QWidget* parent)
    : QDialog(parent), m_config(config), m_paths(std::move(paths)),
      m_applyHotkeys(std::move(applyHotkeys)) {
    resize(900, 730);

    QVBoxLayout* layout = nullptr;
    setupFramelessDialog(this, uiText("Settings"), &layout);

    auto* languageForm = new QFormLayout();
    auto* languageCombo = new QComboBox(this);
    languageCombo->setObjectName("interface_language");
    languageCombo->addItem(uiText("System default"), "system");
    languageCombo->addItem("English", "en");
    languageCombo->addItem(QString::fromUtf8("한국어"), "ko");
    const int languageIndex = languageCombo->findData(
        QString::fromStdString(m_config.get("UI", "language", "system")));
    languageCombo->setCurrentIndex(languageIndex < 0 ? 0 : languageIndex);
    languageForm->addRow(uiText("Language (restart required)"), languageCombo);
    layout->addLayout(languageForm);
    connect(languageCombo, &QComboBox::activated, this,
            [this, languageCombo](int) {
        Config updated = m_config;
        updated.set("UI", "language", languageCombo->currentData().toString().toStdString());
        std::string error;
        if (save_config(updated, &error)) {
            m_config = std::move(updated);
            QMessageBox::information(this, uiText("Language"),
                uiText("Restart Goliath to apply the language and game title changes."));
        } else {
            languageCombo->setCurrentIndex(languageCombo->findData(
                QString::fromStdString(m_config.get("UI", "language", "system"))));
            QMessageBox::warning(this, uiText("Language"), QString::fromStdString(error));
        }
    });

    m_tabs = new QTabWidget();
    m_tabs->setObjectName("settings_tabs");
    layout->addWidget(m_tabs);
    connect(m_tabs, &QTabWidget::currentChanged, this, &SettingsDialog::onTabChanged);

    auto* videoTab = new VideoTab(m_paths.jollygood_settings_ini, m_paths.geolith_ini,
                                  m_paths.jollygood_exe, this);
    m_tabs->addTab(videoTab, uiText("Video"));

    auto* audioTab = new AudioTab(m_config, m_paths.jollygood_settings_ini,
                                  m_paths.geolith_ini, this);
    m_tabs->addTab(audioTab, uiText("Audio"));

    auto* miscTab = new MiscTab(m_paths.jollygood_settings_ini, m_paths.geolith_ini, this);
    m_tabs->addTab(miscTab, uiText("Misc"));

    auto* coreTab = new CoreTab(m_paths.geolith_ini, this);
    m_tabs->addTab(coreTab, uiText("Core"));

    auto* inputWidget = new QWidget();
    m_tabs->addTab(inputWidget, uiText("Input"));
    buildInputTab(inputWidget);

    auto* hotkeyWidget = new QWidget();
    m_tabs->addTab(hotkeyWidget, uiText("Hotkeys"));
    buildHotkeysTab(hotkeyWidget);

    auto* pathWidget = new QWidget();
    m_tabs->addTab(pathWidget, uiText("Path"));
    buildPathTab(pathWidget);

    m_infoTab = new InfoTab(m_paths.jollygood_exe, m_config, this);
    m_tabs->addTab(m_infoTab, uiText("Info"));

    const std::string themeKey =
        m_config.get("UI", "theme", "Dark Modern");
    const Theme& theme = find_theme(themeKey);
    applyComboPopupStyleToDescendants(
        this,
        QString::fromStdString(generate_combo_popup_style(theme)));
}

SettingsDialog::~SettingsDialog() {
    cancelListening();
}

void SettingsDialog::buildHotkeysTab(QWidget* widget) {
    auto* layout = new QVBoxLayout(widget);
    layout->setContentsMargins(16, 16, 16, 0);

    auto* applicationGroup = new QGroupBox(uiText("Goliath shortcuts"), widget);
    auto* applicationLayout = new QVBoxLayout(applicationGroup);
    auto* applicationInfo = new QLabel(
        uiText("These fixed shortcuts are active only while the Goliath window has focus. They do not register global keys or interfere with a running game."),
        applicationGroup);
    applicationInfo->setWordWrap(true);
    applicationInfo->setObjectName("themed_note");
    applicationLayout->addWidget(applicationInfo);
    auto* applicationGrid = new QGridLayout();
    for (std::size_t index = 0; index < kApplicationShortcuts.size(); ++index) {
        const auto& shortcut = kApplicationShortcuts[index];
        const int row = static_cast<int>(index / 2);
        const int column = static_cast<int>(index % 2) * 2;
        auto* action = new QLabel(
            uiText(shortcut.action) + QStringLiteral(":"),
            applicationGroup);
        auto* value = new QLabel(
            QKeySequence(shortcut.sequence).toString(QKeySequence::NativeText),
            applicationGroup);
        applicationGrid->addWidget(action, row, column);
        applicationGrid->addWidget(value, row, column + 1);
    }
    applicationGrid->setColumnStretch(1, 1);
    applicationGrid->setColumnStretch(3, 1);
    applicationLayout->addLayout(applicationGrid);
    layout->addWidget(applicationGroup);

    auto* captureGroup = new QGroupBox(uiText("In-game capture"), widget);
    auto* captureLayout = new QVBoxLayout(captureGroup);
    auto* info = new QLabel(
        uiText("Goliath capture shortcuts work while a game is running. Use a letter, number, function key or punctuation, with or without Ctrl/Alt/Shift. Single keys are active only while the game has focus and will not also reach the game. Clear a field to disable its shortcut. The PNG capture still has a Tools button. GIF recording is experimental and can behave differently across renderers and desktop sessions."));
    info->setWordWrap(true);
    info->setObjectName("themed_note");
    captureLayout->addWidget(info);

    auto* form = new QFormLayout();
    m_gifHotkeyEdit = new QKeySequenceEdit(captureGroup);
    m_pngHotkeyEdit = new QKeySequenceEdit(captureGroup);
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    m_gifHotkeyEdit->setMaximumSequenceLength(1);
    m_pngHotkeyEdit->setMaximumSequenceLength(1);
#endif
    m_gifHotkeyEdit->setObjectName("capture_gif_hotkey");
    m_pngHotkeyEdit->setObjectName("capture_png_hotkey");
    m_gifHotkeyEdit->setClearButtonEnabled(true);
    m_pngHotkeyEdit->setClearButtonEnabled(true);
    const char* gifDefault = "Ctrl+Alt+F12";
#if defined(GOLIATH_WAYLAND_CAPTURE)
    if (QGuiApplication::platformName() == "wayland") gifDefault = "";
#endif
    m_gifHotkeyEdit->setKeySequence(QKeySequence(
        QString::fromStdString(m_config.get("Hotkeys", "gif", gifDefault)),
        QKeySequence::PortableText));
    m_pngHotkeyEdit->setKeySequence(QKeySequence(
        QString::fromStdString(m_config.get("Hotkeys", "png", "")),
        QKeySequence::PortableText));
    form->addRow(uiText("Record GIF (Experimental):"), m_gifHotkeyEdit);
    m_gifHotkeyWarning = new QLabel(captureGroup);
    m_gifHotkeyWarning->setWordWrap(true);
    m_gifHotkeyWarning->setObjectName("themed_note");
    m_gifHotkeyWarning->hide();
    form->addRow("", m_gifHotkeyWarning);
    m_gifDurationCombo = new QComboBox(captureGroup);
    m_gifDurationCombo->setObjectName("capture_duration");
    m_gifDurationCombo->addItem(uiText("5 seconds"), 5);
    m_gifDurationCombo->addItem(uiText("7 seconds"), 7);
    m_gifDurationCombo->addItem(uiText("10 seconds"), 10);
    const QString savedDuration = QString::fromStdString(
        m_config.get("Hotkeys", "gif_duration_seconds", "7"));
    const int durationIndex = m_gifDurationCombo->findData(savedDuration.toInt());
    m_gifDurationCombo->setCurrentIndex(durationIndex < 0 ? 1 : durationIndex);
    form->addRow(uiText("GIF duration:"), m_gifDurationCombo);
    form->addRow(uiText("Capture PNG:"), m_pngHotkeyEdit);
    m_pngHotkeyWarning = new QLabel(captureGroup);
    m_pngHotkeyWarning->setWordWrap(true);
    m_pngHotkeyWarning->setObjectName("themed_note");
    m_pngHotkeyWarning->hide();
    form->addRow("", m_pngHotkeyWarning);
    captureLayout->addLayout(form);

    connect(m_gifHotkeyEdit, &QKeySequenceEdit::keySequenceChanged,
            this, [this]() { updateHotkeyWarnings(); });
    connect(m_pngHotkeyEdit, &QKeySequenceEdit::keySequenceChanged,
            this, [this]() { updateHotkeyWarnings(); });
    auto* buttons = new QHBoxLayout();
    auto* save = new EngravedActionButton(
        uiText("Save Hotkeys"), EngravedActionButton::Glyph::Save, captureGroup);
#if defined(_WIN32) || defined(GOLIATH_X11_CAPTURE) || defined(GOLIATH_WAYLAND_CAPTURE)
    connect(save, &QPushButton::clicked, this, [this]() {
        saveHotkeys();
    });
#endif
    buttons->addWidget(save);

    auto* reset = new EngravedActionButton(
        uiText("Reset to Defaults"), EngravedActionButton::Glyph::Reset,
        captureGroup);
    connect(reset, &QPushButton::clicked, this, [this, gifDefault]() {
        m_gifHotkeyEdit->setKeySequence(QKeySequence(gifDefault,
                                                  QKeySequence::PortableText));
        m_pngHotkeyEdit->clear();
        m_gifDurationCombo->setCurrentIndex(1);
        updateHotkeyWarnings();
    });
    buttons->addWidget(reset);
    layout->addWidget(captureGroup);
    layout->addStretch();
    // Match the other Settings tabs: persistent actions stay in a shallow,
    // fixed footer instead of being embedded in the scrolling/content card.
    layout->addLayout(buttons);
#if !defined(_WIN32)
    m_pngHotkeyEdit->setEnabled(false);
#if defined(GOLIATH_X11_CAPTURE)
    const bool x11 = QGuiApplication::platformName() == "xcb";
#if defined(GOLIATH_WAYLAND_CAPTURE)
    const bool wayland = QGuiApplication::platformName() == "wayland";
#else
    const bool wayland = false;
#endif
    m_gifHotkeyEdit->setEnabled(x11 || wayland);
    m_gifDurationCombo->setEnabled(x11 || wayland);
    reset->setEnabled(x11 || wayland);
    save->setEnabled(x11 || wayland);
    if (wayland) {
        info->setText("On Wayland, the desktop asks you to approve a GIF shortcut. "
                      "Choose a free key; Ctrl+Alt+function keys may be reserved. "
                      "The desktop may assign a different key, especially for single keys. "
                      "While one Goliath game is running, pressing it opens the game-window "
                      "picker. You can also use Tools > Record game GIF. "
                      "PNG capture remains Windows-only.");
    } else {
        info->setText(x11
            ? "On X11, a GIF shortcut works while a Goliath-launched game has focus. "
              "Set a key and duration below, then choose Save hotkeys. Single keys "
              "are consumed by Goliath while playing. Tools > Record game GIF (3s) "
              "is also available. PNG capture remains Windows-only."
            : "Game GIF capture currently requires an X11 desktop session.");
    }
#elif defined(GOLIATH_WAYLAND_CAPTURE)
    const bool wayland = QGuiApplication::platformName() == "wayland";
    m_gifHotkeyEdit->setEnabled(wayland);
    m_gifDurationCombo->setEnabled(wayland);
    reset->setEnabled(wayland);
    save->setEnabled(wayland);
    info->setText(wayland
        ? "Choose a GIF shortcut in the desktop's permission dialog. With a "
          "game running, the shortcut opens the window picker. The desktop "
          "may assign a different key. PNG capture remains Windows-only."
        : "GIF capture requires a Wayland or X11 desktop session.");
#else
    m_gifHotkeyEdit->setEnabled(false);
    m_gifDurationCombo->setEnabled(false);
    reset->setEnabled(false);
    save->setEnabled(false);
    info->setText("Goliath's global capture shortcuts are currently available on Windows only.");
#endif
#endif
    updateHotkeyWarnings();
#if !defined(_WIN32)
#if !defined(GOLIATH_X11_CAPTURE)
    setOptionalNote(m_gifHotkeyWarning, {});
#endif
    setOptionalNote(m_pngHotkeyWarning, {});
#endif
}

void SettingsDialog::updateHotkeyWarnings() {
#if defined(GOLIATH_WAYLAND_CAPTURE)
    if (QGuiApplication::platformName() == "wayland") {
        QString error;
        parseCaptureHotkey(m_gifHotkeyEdit->keySequence(), &error);
        setOptionalNote(
            m_gifHotkeyWarning,
            error.isEmpty()
                ? jgrfWarningForHotkey(m_gifHotkeyEdit->keySequence())
                : error);
        setOptionalNote(m_pngHotkeyWarning, {});
        return;
    }
#endif
    const auto update = [](QKeySequenceEdit* edit, QLabel* label) {
        QString error;
        parseCaptureHotkey(edit->keySequence(), &error);
        const QString note = jgrfWarningForHotkey(edit->keySequence());
        QString shown = error.isEmpty() ? note : error;
        if (error.isEmpty() && !edit->keySequence().isEmpty() &&
            edit->keySequence()[0].keyboardModifiers() == Qt::NoModifier) {
            if (!shown.isEmpty()) shown += " ";
            shown += uiText("This single key will be consumed while the tracked game has focus.");
        }
        setOptionalNote(label, shown);
    };
    update(m_gifHotkeyEdit, m_gifHotkeyWarning);
#if defined(GOLIATH_X11_CAPTURE)
    setOptionalNote(m_pngHotkeyWarning, {});
    return;
#endif
    update(m_pngHotkeyEdit, m_pngHotkeyWarning);
    const auto gif = parseCaptureHotkey(m_gifHotkeyEdit->keySequence());
    const auto png = parseCaptureHotkey(m_pngHotkeyEdit->keySequence());
    if (gif && png && gif->virtualKey &&
        gif->virtualKey == png->virtualKey && gif->modifiers == png->modifiers) {
        setOptionalNote(m_gifHotkeyWarning,
                        uiText("GIF and PNG cannot use the same shortcut."));
        setOptionalNote(m_pngHotkeyWarning,
                        uiText("GIF and PNG cannot use the same shortcut."));
    }
}

void SettingsDialog::saveHotkeys() {
    const QKeySequence gif = m_gifHotkeyEdit->keySequence();
    const QKeySequence png = m_pngHotkeyEdit->keySequence();
    QString applyError;
    if (!m_applyHotkeys(gif, png, &applyError)) {
        QMessageBox::warning(this, uiText("Hotkeys"), applyError);
        return;
    }

    Config candidate = m_config;
    candidate.set("Hotkeys", "gif",
                  gif.toString(QKeySequence::PortableText).toStdString());
    candidate.set("Hotkeys", "png",
                  png.toString(QKeySequence::PortableText).toStdString());
    candidate.set("Hotkeys", "gif_duration_seconds",
                  std::to_string(m_gifDurationCombo->currentData().toInt()));

    std::string saveError;
    if (!save_config(candidate, &saveError)) {
        QMessageBox::warning(
            this, uiText("Hotkeys"),
            uiText("Capture shortcuts were applied for this session but could not be saved.\n\n") +
                QString::fromStdString(saveError));
        return;
    }

    m_config = std::move(candidate);
    QMessageBox::information(this, uiText("Hotkeys"), uiText("Capture shortcuts updated."));
}

void SettingsDialog::buildInputTab(QWidget* inputWidget) {
    auto* pageLayout = new QVBoxLayout(inputWidget);
    pageLayout->setContentsMargins(
        pageLayout->contentsMargins().left(),
        pageLayout->contentsMargins().top(),
        pageLayout->contentsMargins().right(), 0);

    auto* pageScroll = new QScrollArea();
    m_inputScroll = pageScroll;
    pageScroll->setObjectName("input_tab_scroll");
    pageScroll->setWidgetResizable(true);
    pageLayout->addWidget(pageScroll);

    auto* content = new QWidget();
    auto* layout = new QVBoxLayout(content);
    layout->setSpacing(10);
    layout->setContentsMargins(10, 10, 10, 10);
    pageScroll->setWidget(content);

    auto* settingsGroup = new QGroupBox(uiText("JollyGood Input Settings"));
    auto* settingsLayout = new QVBoxLayout(settingsGroup);

    auto* sourceRow = new QHBoxLayout();
    sourceRow->addWidget(new QLabel(uiText("Input Device:")));
    m_inputDeviceCombo = new QComboBox();
    for (const auto& opt : inputDeviceOptions()) {
        m_inputDeviceCombo->addItem(uiText(opt.second.toUtf8().constData()), opt.first);
    }
    m_inputDeviceCombo->setCurrentIndex(0);
    connect(m_inputDeviceCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &SettingsDialog::onInputDeviceChanged);
    sourceRow->addWidget(m_inputDeviceCombo);
    sourceRow->addSpacing(24);

    sourceRow->addWidget(new QLabel(uiText("Capture from:")));
    m_joystickCombo = new QComboBox();
    m_joystickCombo->setMinimumWidth(220);
    m_joystickCombo->setToolTip(
        uiText("Keyboard capture is always active. The selected SDL controller is captured alongside it."));
    connect(m_joystickCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this](int) { cancelListening(); });
    sourceRow->addWidget(m_joystickCombo);
    auto* refreshBtn = new EngravedActionButton(
        uiText("Refresh"), EngravedActionButton::Glyph::Refresh);
    connect(refreshBtn, &QPushButton::clicked, this, &SettingsDialog::refreshJoystickList);
    sourceRow->addWidget(refreshBtn);
    sourceRow->addStretch();
    settingsLayout->addLayout(sourceRow);
    refreshJoystickList();

    auto* jgrfInputGroup = new QGroupBox(uiText("Axis Deadzone"));
    auto* jgrfInputForm = new QFormLayout(jgrfInputGroup);
    m_axisDeadzoneSpin = new QSpinBox();
    m_axisDeadzoneSpin->setRange(0, 9);
    m_axisDeadzoneSpin->setToolTip(
        uiText("JGRF analog-axis deadzone. Range 0-9; default 5. Higher values ignore more movement around the center of an analog axis."));
    jgrfInputForm->addRow(uiText("Axis Deadzone:"), m_axisDeadzoneSpin);

    auto* saveJgrfInputBtn = new EngravedActionButton(
        uiText("Save JGRF Input Settings"), EngravedActionButton::Glyph::Save);
    connect(saveJgrfInputBtn, &QPushButton::clicked,
            this, &SettingsDialog::saveJgrfInputSettings);
    jgrfInputForm->addRow("", saveJgrfInputBtn);
    loadJgrfInputSettings();

    auto* hotkeyNote = new QLabel(QString::fromUtf8(
        "<b>Input capture:</b> The keyboard is always active; the selected SDL "
        "controller is captured alongside it. Click a waiting control again to cancel."
        "<br><br><b>JGRF hotkeys:</b> Keyboard mappings may overlap with frontend hotkeys "
        "(for example <b>F</b> = Fullscreen, <b>M</b> = Mute, <b>P</b> = Pause). "
        "Hover a mapped button for details. Press <b>Shift+Tab</b> in JGRF to "
        "toggle frontend hotkey processing."
        "<br><br><b>Conflicts:</b> A warning marks inputs assigned to more than "
        "one displayed action. Conflicts remain saveable because some duplicate "
        "assignments are intentional. Right-click a control to reset only that "
        "mapping to its built-in default."));
    hotkeyNote->setWordWrap(true);
    auto* mappingHelpGroup = new QGroupBox(uiText("Mapping Help"));
    auto* mappingHelpLayout = new QVBoxLayout(mappingHelpGroup);
    mappingHelpLayout->addWidget(hotkeyNote);

    auto* auxiliaryRow = new QHBoxLayout();
    auxiliaryRow->setSpacing(8);
    auxiliaryRow->addWidget(createInputSectionToggle(
        uiText("Advanced Input Settings"), jgrfInputGroup, settingsGroup));
    auxiliaryRow->addWidget(createInputSectionToggle(
        uiText("Mapping Help"), mappingHelpGroup, settingsGroup));
    auxiliaryRow->addStretch();
    settingsLayout->addLayout(auxiliaryRow);
    settingsLayout->addWidget(jgrfInputGroup);
    settingsLayout->addWidget(mappingHelpGroup);
    layout->addWidget(settingsGroup);

    m_inputConflictSummary = new QLabel();
    m_inputConflictSummary->setWordWrap(true);
    m_inputConflictSummary->setObjectName("themed_note");
    m_inputConflictSummary->hide();
    layout->addWidget(m_inputConflictSummary);

    m_inputContainer = new QWidget();
    m_inputLayout = new QVBoxLayout(m_inputContainer);
    m_inputLayout->setSizeConstraint(QLayout::SetMinimumSize);
    layout->addWidget(m_inputContainer);

    auto* inputBtnRow = new QHBoxLayout();
    auto* saveBtn = new EngravedActionButton(
        "Save Input Config", EngravedActionButton::Glyph::Save);
    connect(saveBtn, &QPushButton::clicked, this, &SettingsDialog::saveInputConfig);
    inputBtnRow->addWidget(saveBtn);

    auto* resetBtn = new EngravedActionButton(
        uiText("Reset to Defaults"), EngravedActionButton::Glyph::Reset);
    connect(resetBtn, &QPushButton::clicked, this, &SettingsDialog::resetInputConfig);
    inputBtnRow->addWidget(resetBtn);

    auto* profilesBtn = new EngravedActionButton(
        "Controller Profiles...", EngravedActionButton::Glyph::Profiles);
    profilesBtn->setObjectName("controller_profiles_button");
    profilesBtn->setToolTip(
        "Save, apply, rename, update, or delete reusable controller mappings.");
    connect(profilesBtn, &QPushButton::clicked,
            this, &SettingsDialog::openControllerProfiles);
    inputBtnRow->addWidget(profilesBtn);
    inputBtnRow->addStretch();
    // Keep actions visible while the controller mapping list scrolls.
    pageLayout->addLayout(inputBtnRow);

    int storedDevice = storedInputProfile();
    int idx = m_inputDeviceCombo->findData(storedDevice);
    if (idx >= 0) {
        m_inputDeviceCombo->blockSignals(true);
        m_inputDeviceCombo->setCurrentIndex(idx);
        m_inputDeviceCombo->blockSignals(false);
    }

    loadInputConfig();
}

void SettingsDialog::buildPathTab(QWidget* pathWidget) {
    auto* pathLayout = new QVBoxLayout(pathWidget);
    pathLayout->setContentsMargins(
        pathLayout->contentsMargins().left(),
        pathLayout->contentsMargins().top(),
        pathLayout->contentsMargins().right(), 0);

    auto* pathsGroup = new QGroupBox("Paths");
    auto* pathsLayout = new QVBoxLayout(pathsGroup);

    for (const auto& ps : pathSettings()) {
        auto* row = new QHBoxLayout();
        auto* lbl = new QLabel(QString("%1:").arg(uiText(ps.label)));
        lbl->setFixedWidth(190);
        row->addWidget(lbl);

        auto* entry = new QLineEdit(path_to_qstring(resolve_path(m_config, ps.key)));
        entry->setReadOnly(true);
        row->addWidget(entry);

        auto* btn = new EngravedActionButton(
            uiText("Browse..."), EngravedActionButton::Glyph::Browse);
        std::string key = ps.key;
        QString label = uiText(ps.label);
        connect(btn, &QPushButton::clicked, this, [this, key, label]() {
            browsePath(key, label);
        });
        row->addWidget(btn);

        m_pathEntries[ps.key] = entry;
        pathsLayout->addLayout(row);
    }

    auto* note = new QLabel("After saving, use Tools \xE2\x86\x92 Rescan ROMs (or F5) "
                             "so the library picks up the new folders.");
    note->setWordWrap(true);
    pathsLayout->addWidget(note);

    pathLayout->addWidget(pathsGroup);
    pathLayout->addStretch();

    auto* saveBtn = new EngravedActionButton(
        uiText("Save Path Settings"), EngravedActionButton::Glyph::Save);
    connect(saveBtn, &QPushButton::clicked, this, &SettingsDialog::savePathConfig);
    pathLayout->addWidget(saveBtn);
}

void SettingsDialog::loadJgrfInputSettings() {
    if (!m_axisDeadzoneSpin) return;

    auto validDeadzone = [](int value) { return value >= 0 && value <= 9; };

    IniDocument cfg;
    cfg.load(m_paths.jollygood_settings_ini);
    int value = kDefaultAxisDeadzone;
    if (cfg.has_option("input", "axis_deadzone")) {
        try {
            const int candidate = std::stoi(cfg.get("input", "axis_deadzone"));
            value = validDeadzone(candidate) ? candidate : kDefaultAxisDeadzone;
        } catch (...) {
            value = kDefaultAxisDeadzone;
        }
    }

    // JGRF applies geolith.ini after settings.ini. A valid core-specific
    // [input] override therefore represents the effective runtime value.
    IniDocument coreCfg;
    coreCfg.load(m_paths.geolith_ini);
    if (coreCfg.has_option("input", "axis_deadzone")) {
        try {
            const int overrideValue = std::stoi(coreCfg.get("input", "axis_deadzone"));
            if (validDeadzone(overrideValue)) value = overrideValue;
        } catch (...) {
        }
    }

    m_axisDeadzoneSpin->setValue(value);
}

bool SettingsDialog::persistJgrfInputSettings(int deadzone,
                                              std::string* error) {
    IniDocument cfg;
    IniDocument coreCfg;
    prepare_jgrf_input_documents(m_paths, deadzone, cfg, coreCfg);

    return save_ini_documents({
        {m_paths.jollygood_settings_ini, &cfg},
        {m_paths.geolith_ini, &coreCfg},
    }, error);
}

void SettingsDialog::saveJgrfInputSettings() {
    if (!m_axisDeadzoneSpin) return;

    std::string error;
    if (!persistJgrfInputSettings(m_axisDeadzoneSpin->value(), &error)) {
        QMessageBox::warning(
            this, "JGRF Input Settings",
            QStringLiteral(
                "The JGRF input settings could not be saved as one "
                "transaction.\n\n") +
                QString::fromStdString(error));
    }
}

int SettingsDialog::storedInputProfile() const {
    const std::string stored = m_config.get("UI", "input_device", "");
    if (!stored.empty()) {
        try {
            const int value = std::stoi(stored);
            if (value >= 1 && value <= 5) return value;
        } catch (...) {
        }
    }

    // Migration fallback for configurations made before the frontend profile
    // was stored separately. Only 1..3 were ever valid Geolith values.
    IniDocument cfg;
    cfg.load(m_paths.geolith_ini);
    try {
        const int value = std::stoi(cfg.get("geolith", "input", "1"));
        if (value >= 1 && value <= 3) return value;
    } catch (...) {
    }
    return 1;
}

int SettingsDialog::currentInputProfile() const {
    if (m_inputDeviceCombo) {
        const int value = m_inputDeviceCombo->currentData().toInt();
        if (value >= 1 && value <= 5) return value;
    }
    return storedInputProfile();
}

QStringList SettingsDialog::targetInputSections(int device) const {
    if (device < 0) device = currentInputProfile();

    QStringList sections;
    for (const std::string& section : controller_profile_sections(device)) {
        sections << QString::fromStdString(section);
    }
    return sections;
}

void SettingsDialog::onTabChanged(int index) {
    cancelListening();

    const QString tabName = m_tabs->tabText(index);
    if (tabName == "Info") {
        if (m_infoTab) m_infoTab->activate();
        return;
    }
    if (tabName != "Input") return;
    // Keep the Input tab on Goliath's frontend profile. V-Liner and
    // Irritating Maze both use Geolith's Auto mode underneath.
    const int storedDevice = storedInputProfile();
    if (m_inputDeviceCombo) {
        int idx = m_inputDeviceCombo->findData(storedDevice);
        if (idx >= 0 && m_inputDeviceCombo->currentIndex() != idx) {
            m_inputDeviceCombo->setCurrentIndex(idx);
        }
    }
    int device = currentInputProfile();
    if (m_lastInputDevice != device) {
        loadInputConfig();
    }
}

void SettingsDialog::onInputDeviceChanged(int) {
    cancelListening();
    loadInputConfig();
}

std::string SettingsDialog::canonicalInputKey(const std::string& section, const std::string& key) const {
    return canonical_input_key(section, key);
}

IniDocument SettingsDialog::defaultInputConfigDocument(int device) const {
    if (device < 0) device = currentInputProfile();

    IniDocument doc;
    for (const QString& qsection : targetInputSections(device)) {
        std::string section = qsection.toStdString();
        auto keysIt = input_defs().find(section);
        if (keysIt == input_defs().end()) continue;

        doc.ensure_section(section);
        auto defIt = default_input_config().find(section);
        for (const std::string& key : keysIt->second) {
            std::string value;
            if (defIt != default_input_config().end()) {
                auto kIt = defIt->second.find(key);
                if (kIt != defIt->second.end()) value = kIt->second;
            }
            doc.set(section, key, value);
        }
    }
    return doc;
}

std::pair<std::string, std::string> SettingsDialog::normalizeInputValue(const std::string& valueIn) const {
    return normalize_input_value(valueIn);
}

void SettingsDialog::addInputRow(const QString& section, const QString& key, const std::string& value) {
    auto* rowWidget = new QWidget();
    auto* row = new QHBoxLayout(rowWidget);
    auto* label = new QLabel(key);
    label->setFixedWidth(100);
    row->addWidget(label);

    auto [stored, display] = normalizeInputValue(value);
    auto* btn = new QPushButton(!value.empty() ? QString::fromStdString(display) : "--");
    btn->setProperty("input_value", !value.empty() ? QString::fromStdString(stored) : QString());
    configureInputButton(btn, section, key);
    row->addWidget(btn);

    m_inputEntries.push_back(InputRow{section, key, btn});
    m_inputLayout->addWidget(rowWidget);
}

void SettingsDialog::configureInputButton(
        QPushButton* button,
        const QString& section,
        const QString& key) {
    connect(button, &QPushButton::clicked,
            this, [this, button, section, key]() {
                startListening(button, section, key);
            });
    button->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(button, &QWidget::customContextMenuRequested,
            this, [this, button, section, key](const QPoint& point) {
                QMenu menu(button);
                QAction* resetAction = menu.addAction("Reset this mapping to default");
                if (menu.exec(button->mapToGlobal(point)) == resetAction)
                    resetOneInputMapping(section, key);
            });
}

void SettingsDialog::resetOneInputMapping(
        const QString& section,
        const QString& key) {
    cancelListening();

    std::string value;
    const std::string stdSection = section.toStdString();
    const std::string stdKey = key.toStdString();
    const auto defaultSection = default_input_config().find(stdSection);
    if (defaultSection != default_input_config().end()) {
        const auto defaultKey = defaultSection->second.find(stdKey);
        if (defaultKey != defaultSection->second.end())
            value = defaultKey->second;
    }

    for (const InputRow& row : m_inputEntries) {
        if (row.section == section && row.key == key) {
            row.button->setProperty(
                "input_value", QString::fromStdString(value));
            break;
        }
    }
    updateInputMappingPresentation();
}

void SettingsDialog::updateInputMappingPresentation() {
    const int scrollPosition = m_inputScroll
        ? m_inputScroll->verticalScrollBar()->value()
        : 0;

    std::vector<InputBindingAssignment> assignments;
    assignments.reserve(m_inputEntries.size());
    for (const InputRow& row : m_inputEntries) {
        const QString stored = row.button->property("input_value").toString();
        if (stored.isEmpty()) continue;
        assignments.push_back({
            row.section.toStdString(),
            row.key.toStdString(),
            stored.toStdString(),
            false,
        });
    }

    const InputBindingConflicts conflicts =
        find_input_binding_conflicts(assignments);
    std::size_t conflictedActions = 0;
    for (const auto& [binding, uses] : conflicts) {
        static_cast<void>(binding);
        conflictedActions += uses.size();
    }

    if (m_inputConflictSummary) {
        if (conflicts.empty()) {
            m_inputConflictSummary->hide();
        } else {
            m_inputConflictSummary->setText(
                QString::fromUtf8(
                    "\xE2\x9A\xA0 %1 conflicting input %2 across %3 actions. "
                    "Saving remains allowed; hover the marked controls for details.")
                    .arg(static_cast<qulonglong>(conflicts.size()))
                    .arg(conflicts.size() == 1 ? "binding" : "bindings")
                    .arg(static_cast<qulonglong>(conflictedActions)));
            m_inputConflictSummary->show();
        }
    }

    for (const InputRow& row : m_inputEntries) {
        const std::string section = row.section.toStdString();
        const std::string key = row.key.toStdString();
        const QString rawValue = row.button->property("input_value").toString();
        const auto [stored, display] = normalizeInputValue(rawValue.toStdString());
        const auto normalized = normalize_input_binding_for_definition(
            section, key, stored);

        QString shown = rawValue.isEmpty()
            ? QStringLiteral("--")
            : QString::fromStdString(display);
        QString tooltip = inputMappingTooltip(
            rawValue.isEmpty() ? QString() : QString::fromStdString(stored));

        if (!rawValue.isEmpty() && !normalized.has_value()) {
            shown = QStringLiteral("Invalid: ") + shown;
        } else if (normalized.has_value()) {
            const auto conflict = conflicts.find(*normalized);
            if (conflict != conflicts.end()) {
                shown.prepend(QString::fromUtf8("\xE2\x9A\xA0 "));
                tooltip += QString::fromUtf8(
                    "\n\n\xE2\x9A\xA0 Also assigned to:");
                for (const InputBindingAssignment& use : conflict->second) {
                    if (use.section == section && use.key == key) continue;
                    tooltip += QString("\n- %1 / %2")
                        .arg(friendlySectionName(
                                 QString::fromStdString(use.section)),
                             QString::fromStdString(use.key));
                }
                tooltip += "\n\nThis warning does not block saving.";
            }
        }

        setButtonDisplayText(row.button, shown);
        row.button->setToolTip(tooltip);
    }

    restore_scroll_position_later(m_inputScroll, scrollPosition);
}

ControllerProfileBindings
SettingsDialog::currentControllerProfileBindings() const {
    ControllerProfileBindings bindings;
    for (const InputRow& row : m_inputEntries) {
        bindings[row.section.toStdString()][row.key.toStdString()] =
            row.button->property("input_value").toString().toStdString();
    }
    return sanitize_controller_profile_bindings(
        currentInputProfile(), bindings);
}

void SettingsDialog::applyControllerProfile(
        const ControllerProfileBindings& bindings) {
    cancelListening();
    const ControllerProfileBindings sanitized =
        sanitize_controller_profile_bindings(currentInputProfile(), bindings);
    for (const InputRow& row : m_inputEntries) {
        std::string value;
        const auto section = sanitized.find(row.section.toStdString());
        if (section != sanitized.end()) {
            const auto key = section->second.find(row.key.toStdString());
            if (key != section->second.end()) value = key->second;
        }
        row.button->setProperty("input_value", QString::fromStdString(value));
    }
    updateInputMappingPresentation();
}

void SettingsDialog::openControllerProfiles() {
    cancelListening();
    ControllerProfilesDialog dialog(
        m_paths.controller_profiles_json,
        currentInputProfile(),
        currentControllerProfileBindings(),
        [this](const ControllerProfileBindings& bindings) {
            applyControllerProfile(bindings);
        },
        this);
    dialog.exec();
}

void SettingsDialog::loadInputConfig() {
    QLayoutItem* child;
    while ((child = m_inputLayout->takeAt(0)) != nullptr) {
        if (child->widget()) child->widget()->deleteLater();
        delete child;
    }
    m_inputEntries.clear();

    int device = currentInputProfile();
    QStringList targetSections = targetInputSections(device);

    IniDocument config;
    if (!fs::is_regular_file(m_paths.input_config)) {
        config = defaultInputConfigDocument(device);
        std::string error;
        if (!config.save(m_paths.input_config, &error)) {
            QMessageBox::warning(
                this, "Input Configuration",
                QStringLiteral(
                    "The default input configuration could not be created. "
                    "Defaults are available for this session but were not "
                    "saved.\n\n") +
                    QString::fromStdString(error));
        }
    } else {
        config.load(m_paths.input_config);
    }
    for (const QString& qs : targetSections) {
        config.ensure_section(qs.toStdString());
    }

    for (const QString& qs : targetSections) {
        std::string section = qs.toStdString();

        std::vector<std::string> orderedCanonical;
        std::map<std::string, std::string> values;
        for (const std::string& rawKey : config.options(section)) {
            std::string canon = canonicalInputKey(section, rawKey);
            if (values.find(canon) == values.end()) orderedCanonical.push_back(canon);
            values[canon] = config.get(section, rawKey);
        }

        std::vector<std::string> shownKeys;
        auto defIt = input_defs().find(section);
        if (defIt != input_defs().end()) shownKeys = defIt->second;
        for (const auto& k : orderedCanonical) {
            if (std::find(shownKeys.begin(), shownKeys.end(), k) == shownKeys.end()) {
                shownKeys.push_back(k);
            }
        }

        const QString sectionTitle = friendlySectionName(qs);
        InputPanelWidget* widget = nullptr;
        if (section.starts_with("neogeojs") && keysSubsetOfInputDefs(ControllerInputWidget::KEYS, section)) {
            widget = new ControllerInputWidget(sectionTitle, m_inputContainer);
        } else if (section == "neogeomahjong" && keysSubsetOfInputDefs(MahjongInputWidget::KEYS, section)) {
            widget = new MahjongInputWidget(sectionTitle, m_inputContainer);
        } else if (section == "neogeovliner" && keysSubsetOfInputDefs(VlinerInputWidget::KEYS, section)) {
            widget = new VlinerInputWidget(sectionTitle, m_inputContainer);
        } else if (section == "neogeoirrmaze" && keysSubsetOfInputDefs(IrrmazeInputWidget::KEYS, section)) {
            widget = new IrrmazeInputWidget(sectionTitle, m_inputContainer);
        } else if (section == "neogeosystem" && keysSubsetOfInputDefs(SystemInputWidget::KEYS, section)) {
            widget = new SystemInputWidget(sectionTitle, m_inputContainer);
        }

        if (widget) {
            m_inputLayout->addWidget(widget);
        } else {
            auto* header = new QLabel(
                QString("<b>%1</b>").arg(friendlySectionName(qs)));
            header->setObjectName("section_heading");
            m_inputLayout->addWidget(header);
        }

        for (const std::string& key : shownKeys) {
            std::string value;
            auto vIt = values.find(key);
            if (vIt != values.end()) value = vIt->second;
            if (value.empty()) {
                auto dsIt = default_input_config().find(section);
                if (dsIt != default_input_config().end()) {
                    auto dkIt = dsIt->second.find(key);
                    if (dkIt != dsIt->second.end()) value = dkIt->second;
                }
            }

            QPushButton* btn = widget ? widget->button(QString::fromStdString(key)) : nullptr;
            if (!btn) {
                addInputRow(qs, QString::fromStdString(key), value);
                continue;
            }

            const std::string stored = normalizeInputValue(value).first;
            btn->setProperty("input_value", !value.empty() ? QString::fromStdString(stored) : QString());

            QString qsection = qs;
            QString qkey = QString::fromStdString(key);
            configureInputButton(btn, qsection, qkey);

            m_inputEntries.push_back(InputRow{qsection, qkey, btn});
        }
    }

    m_inputLayout->addStretch();
    m_lastInputDevice = device;
    updateInputMappingPresentation();
}

void SettingsDialog::refreshJoystickList() {
    if (!m_joystickCombo) return;
    cancelListening();

    std::uint32_t previousId = m_joystickCombo->currentData().toUInt();
    m_joystickCombo->clear();
    m_detectedJoysticks = list_joysticks();

    if (m_detectedJoysticks.empty()) {
        m_joystickCombo->addItem("Keyboard only (no controller detected)", 0u);
        m_joystickCombo->setEnabled(false);
        return;
    }

    m_joystickCombo->setEnabled(true);
    int restoreIdx = 0;
    for (const DetectedJoystick& js : m_detectedJoysticks) {
        m_joystickCombo->addItem(
            QString("Keyboard + Port %1 (j%2): %3")
                .arg(js.port + 1)
                .arg(js.port)
                .arg(js.name),
            js.instanceId);
        if (js.instanceId == previousId) restoreIdx = m_joystickCombo->count() - 1;
    }
    m_joystickCombo->setCurrentIndex(restoreIdx);
}

void SettingsDialog::startListening(QPushButton* btn, const QString& section, const QString& key) {
    if (btn == m_listeningBtn) {
        cancelListening();
        return;
    }
    cancelListening();

    m_listeningBtn = btn;
    m_listeningSection = section;
    m_listeningKey = key;
    m_listeningDisplay = buttonDisplayText(btn);
    m_listeningTooltip = btn->toolTip();
    setButtonDisplayText(btn, QString::fromUtf8("\xE2\x8C\xA8\xEF\xB8\x8F/\xF0\x9F\x8E\xAE Waiting..."));
    btn->setToolTip(
        "Press a keyboard key or use the selected controller. "
        "Click this control again to cancel.");
    setButtonListeningStyle(btn);

    const int scrollPosition = m_inputScroll
        ? m_inputScroll->verticalScrollBar()->value()
        : 0;
    restore_scroll_position_later(m_inputScroll, scrollPosition);

    // Redirect ALL keyboard events to this dialog while listening - otherwise
    // arrow keys/Tab are consumed by Qt focus navigation on the focused
    // button and never reach keyPressEvent().
    grabKeyboard();

    if (m_joystickCombo && m_joystickCombo->isEnabled() && m_joystickCombo->currentIndex() >= 0) {
        std::uint32_t instanceId = m_joystickCombo->currentData().toUInt();
        int port = m_joystickCombo->currentIndex();
        for (const DetectedJoystick& js : m_detectedJoysticks) {
            if (js.instanceId == instanceId) { port = js.port; break; }
        }

        const bool analogAxis = is_analog_input_definition(
            section.toStdString(), key.toStdString());
        const JoystickCaptureMode mode = analogAxis
            ? JoystickCaptureMode::AnalogAxis
            : JoystickCaptureMode::Digital;
        m_jsThread = new JoystickListener(instanceId, port, mode, this);
        connect(m_jsThread, &JoystickListener::mapped, this, &SettingsDialog::onJoystickMapped);
        connect(m_jsThread, &QThread::finished, this, [this]() {
            auto* finished = qobject_cast<JoystickListener*>(sender());
            if (finished == m_jsThread) m_jsThread = nullptr;
            if (finished) finished->deleteLater();
        });
        m_jsThread->start();
    }
}

void SettingsDialog::onJoystickMapped(QString code) {
    applyMapping(code);
}

void SettingsDialog::stopJoystickListener() {
    if (!m_jsThread) return;

    JoystickListener* listener = m_jsThread;
    m_jsThread = nullptr;
    listener->stop();
}

void SettingsDialog::cancelListening() {
    const bool restoreScroll = m_listeningBtn != nullptr;
    const int scrollPosition = m_inputScroll
        ? m_inputScroll->verticalScrollBar()->value()
        : 0;
    stopJoystickListener();

    if (m_listeningBtn) {
        setButtonDisplayText(m_listeningBtn, m_listeningDisplay);
        m_listeningBtn->setToolTip(m_listeningTooltip);
        resetButtonStyle(m_listeningBtn);
    }

    m_listeningBtn = nullptr;
    m_listeningSection.clear();
    m_listeningKey.clear();
    m_listeningDisplay.clear();
    m_listeningTooltip.clear();
    if (QWidget::keyboardGrabber() == this) releaseKeyboard();
    if (restoreScroll)
        restore_scroll_position_later(m_inputScroll, scrollPosition);
}

void SettingsDialog::applyMapping(const QString& code, const QString& displayNameIn) {
    if (!m_listeningBtn) return;

    const auto normalized = normalize_input_binding_for_definition(
        m_listeningSection.toStdString(),
        m_listeningKey.toStdString(),
        code.toStdString());
    if (!normalized.has_value()) {
        setButtonDisplayText(m_listeningBtn, "Unsupported input; try again...");
        m_listeningBtn->setToolTip(
            "This value is not safe for the selected JGRF input definition. "
            "Click the control again to cancel.");
        return;
    }

    static_cast<void>(displayNameIn);
    m_listeningBtn->setProperty(
        "input_value", QString::fromStdString(*normalized));
    resetButtonStyle(m_listeningBtn);
    stopJoystickListener();
    m_listeningBtn = nullptr;
    m_listeningSection.clear();
    m_listeningKey.clear();
    m_listeningDisplay.clear();
    m_listeningTooltip.clear();
    if (QWidget::keyboardGrabber() == this) releaseKeyboard();
    updateInputMappingPresentation();
}

bool SettingsDialog::event(QEvent* e) {
    // While listening, consume KeyPress here so Qt does not use arrows/Tab
    // for focus navigation before keyPressEvent() gets a chance to run.
    if (m_listeningBtn && e->type() == QEvent::KeyPress) {
        keyPressEvent(static_cast<QKeyEvent*>(e));
        return true;
    }
    return QDialog::event(e);
}

void SettingsDialog::keyPressEvent(QKeyEvent* event) {
    if (!m_listeningBtn) {
        QDialog::keyPressEvent(event);
        return;
    }

    int key = event->key();
    if (key == Qt::Key_Shift || key == Qt::Key_Control || key == Qt::Key_Alt || key == Qt::Key_Meta) {
        return;
    }

    if (is_analog_input_definition(m_listeningSection.toStdString(),
                                   m_listeningKey.toStdString())) {
        // JGRF deliberately refuses digital inputs for emulated axes. Keep
        // listening for a physical analog joystick axis rather than saving a
        // keyboard/button value that JGRF will ignore.
        setButtonDisplayText(m_listeningBtn, "Move analog axis...");
        m_listeningBtn->setToolTip(
            "Analog axis required. Keyboard keys, buttons and hats cannot be assigned here.");
        return;
    }

    std::optional<int> sdl;
    if (event->modifiers() & Qt::KeypadModifier) {
        auto& kp = qt_keypad_to_sdl_scancode();
        auto it = kp.find(key);
        if (it != kp.end()) sdl = it->second;
    }
    if (!sdl.has_value()) {
        auto& main = qt_key_to_sdl_scancode();
        auto it = main.find(key);
        if (it != main.end()) sdl = it->second;
    }
    if (!sdl.has_value() && !event->text().isEmpty()) {
        QString alias = event->text().toLower().replace(" ", "");
        auto& n2s = name_to_sdl_scancode();
        auto it = n2s.find(alias.toStdString());
        if (it != n2s.end()) sdl = it->second;
    }

    if (sdl.has_value()) {
        auto& names = sdl_scancode_names();
        auto it = names.find(*sdl);
        QString name = it != names.end() ? QString::fromStdString(it->second) : QString::number(*sdl);
        applyMapping(QString::number(*sdl), name);
    } else {
        QString name = QKeySequence(key).toString().toLower();
        applyMapping(name);
    }
}

void SettingsDialog::saveInputConfig() {
    cancelListening();

    IniDocument config;
    config.load(m_paths.input_config); // preserve mappings for other input devices

    for (const InputRow& row : m_inputEntries) {
        std::string section = row.section.toStdString();
        std::string key = row.key.toStdString();

        // drop stale duplicate raw keys that normalize to this canonical key
        for (const std::string& rawKey : config.options(section)) {
            if (rawKey != key && canonicalInputKey(section, rawKey) == key) {
                config.remove_option(section, rawKey);
            }
        }

        QVariant prop = row.button->property("input_value");
        QString value = prop.isValid() ? prop.toString() : QString();
        if (value.isEmpty()) {
            value = buttonDisplayText(row.button);
        }
        if (value.isEmpty() || value == "--") {
            config.remove_option(section, key);
            continue;
        }

        config.set(section, key, value.toStdString());
    }

    for (const std::string& section : config.sections()) {
        if (config.options(section).empty()) {
            config.remove_section(section);
        }
    }

    Config candidate = m_config;
    IniDocument coreCfg;
    coreCfg.load(m_paths.geolith_ini);
    if (m_inputDeviceCombo) {
        const int profile = currentInputProfile();

        // Geolith only accepts input=0..3. V-Liner and Irritating Maze are
        // auto-detected from the loaded game's flags, so their frontend
        // profiles must use input=0 (Auto), never invalid values 4/5.
        coreCfg.set("geolith", "input",
                    std::to_string(geolith_input_setting_for_device(profile)));

        // Persist Goliath's richer profile separately so V-Liner/Irrmaze stay
        // selected when the Settings dialog is reopened.
        candidate.set("UI", "input_device", std::to_string(profile));
    }

    std::string error;
    if (!save_files_transactionally({
            {m_paths.input_config, config.serialized_text()},
            {m_paths.geolith_ini, coreCfg.serialized_text()},
            {get_config_path(), candidate.serialized_text()},
        }, &error)) {
        QMessageBox::warning(
            this, "Input Configuration",
            QStringLiteral(
                "The input mappings and selected device could not be saved "
                "as one transaction.\n\n") +
                QString::fromStdString(error));
        return;
    }

    m_config = std::move(candidate);
}

void SettingsDialog::resetInputConfig() {
    cancelListening();

    int device = currentInputProfile();
    QStringList sections = targetInputSections(device);

    auto reply = QMessageBox::question(this, "Reset Input Config",
        "Reset the JGRF Axis Deadzone and all key/button mappings for the "
        "currently selected input device to their defaults? This does not "
        "affect mappings for other input devices.",
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (reply != QMessageBox::Yes) return;

    IniDocument config;
    config.load(m_paths.input_config); // preserve mappings for other input devices

    for (const QString& qsection : sections) {
        std::string section = qsection.toStdString();
        auto keysIt = input_defs().find(section);
        if (keysIt == input_defs().end()) continue;

        auto defIt = default_input_config().find(section);
        for (const std::string& key : keysIt->second) {
            std::string value;
            if (defIt != default_input_config().end()) {
                auto kIt = defIt->second.find(key);
                if (kIt != defIt->second.end()) value = kIt->second;
            }
            config.set(section, key, value);
        }
    }

    // "Reset to Defaults" applies to the whole Input tab. Axis Deadzone is
    // a global JGRF input setting, while the mappings above are profile-specific.
    IniDocument settings;
    IniDocument coreCfg;
    prepare_jgrf_input_documents(
        m_paths, kDefaultAxisDeadzone, settings, coreCfg);

    std::string error;
    if (!save_ini_documents({
            {m_paths.input_config, &config},
            {m_paths.jollygood_settings_ini, &settings},
            {m_paths.geolith_ini, &coreCfg},
        }, &error)) {
        QMessageBox::warning(
            this, "Reset Input Configuration",
            QStringLiteral(
                "The input mappings and JGRF deadzone could not be reset "
                "as one transaction.\n\n") +
                QString::fromStdString(error));
        return;
    }

    if (m_axisDeadzoneSpin) m_axisDeadzoneSpin->setValue(kDefaultAxisDeadzone);
    loadInputConfig();
}

void SettingsDialog::browsePath(const std::string& key, const QString& label) {
    const QString current = path_to_qstring(resolve_path(m_config, key));
    const QString path = QFileDialog::getExistingDirectory(
        this, "Select " + label,
        current.isEmpty() ? path_to_qstring(m_paths.base_dir) : current);

    if (!path.isEmpty()) {
        m_pathEntries[key]->setText(path);
    }
}

void SettingsDialog::savePathConfig() {
    Config candidate = m_config;
    for (const auto& ps : pathSettings()) {
        auto it = m_pathEntries.find(ps.key);
        if (it == m_pathEntries.end()) continue;
        candidate.set(
            "Paths", ps.key,
            path_to_utf8(qstring_to_path(relativePath(it->second->text()))));
    }

    std::string error;
    if (!save_config(candidate, &error)) {
        QMessageBox::warning(
            this, "Path Settings",
            QStringLiteral("Path settings could not be saved.\n\n") +
                QString::fromStdString(error));
        return;
    }

    m_config = std::move(candidate);
}

QString SettingsDialog::relativePath(const QString& path) const {
    const fs::path selected = qstring_to_path(path).lexically_normal();
    const fs::path base = m_paths.base_dir.lexically_normal();
    std::error_code ec;
    const fs::path relative = fs::relative(selected, base, ec);
    if (!ec && !relative.empty() && !relative.is_absolute() &&
        relative != fs::path(".") && *relative.begin() != fs::path("..")) {
        QString portable = path_to_qstring(relative);
        return portable.replace('\\', '/');
    }
    return path;
}

void SettingsDialog::closeEvent(QCloseEvent* event) {
    cancelListening();
    QDialog::closeEvent(event);
}

} // namespace goliath
