#include "common/localization.hpp"
#include "game/game_model.hpp"
#include <QLocale>

namespace goliath {
QString interfaceLanguage(const Config& config) {
    const std::string choice = config.get("UI", "language", "system");
    if (choice == "ko" || choice == "en") return QString::fromStdString(choice);
    return QLocale::system().language() == QLocale::Korean ? "ko" : "en";
}

std::vector<Game> localizedLibrary(const std::vector<Game>& catalog, bool japanese) {
    auto games = catalog;
    if (!japanese) return games;
    for (auto& game : games) {
        const std::string englishDisplay = game.display;
        // A missing canonical parent must not borrow an unrelated clone title.
        const Rom* parent = nullptr;
        for (const auto& rom : game.roms) {
            if (rom.main && (!game.main_rom || rom.file == *game.main_rom)) {
                parent = &rom;
                break;
            }
        }
        if (parent && parent->alt_title &&
            !QString::fromStdString(*parent->alt_title).trimmed().isEmpty()) {
            game.name = *parent->alt_title;
            game.display = *parent->alt_title;
        }
        for (auto& rom : game.roms) {
            if (!rom.alt_title ||
                QString::fromStdString(*rom.alt_title).trimmed().isEmpty()) continue;
            const std::string english = rom.name && !rom.name->empty()
                ? *rom.name : (rom.label && !rom.label->empty() ? *rom.label : englishDisplay);
            rom.name = *rom.alt_title;
            rom.alt_title = english;
        }
    }
    return games;
}
}
