#pragma once
#include "common/goliath_common.hpp"
#include <QCoreApplication>
#include <QString>
#include <vector>

namespace goliath {
struct Game;
inline QString uiText(const char* source) {
    return QCoreApplication::translate("Goliath", source);
}
// Resolve an explicit choice or the operating system language.
QString interfaceLanguage(const Config& config);
// Returns a presentation copy. Catalog names, media identities and files stay intact.
std::vector<Game> localizedLibrary(const std::vector<Game>& catalog, bool japanese);
}
